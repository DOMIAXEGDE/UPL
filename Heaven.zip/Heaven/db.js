// Tiny IndexedDB wrapper with graceful localStorage fallback
(function(global){
  const DB_NAME = 'CharsetGridDB';
  const DB_VERSION = 1;
  const STORE_SETTINGS = 'settings';
  const STORE_SESSIONS = 'sessions';
  const STORE_GRIDS = 'grids';

  function withIDB(action){
    return new Promise((resolve, reject) => {
      if(!('indexedDB' in global)){
        return reject(new Error('IndexedDB not supported'));
      }
      const openReq = indexedDB.open(DB_NAME, DB_VERSION);
      openReq.onupgradeneeded = (e) => {
        const db = openReq.result;
        if(!db.objectStoreNames.contains(STORE_SETTINGS)){
          db.createObjectStore(STORE_SETTINGS, { keyPath: 'id' });
        }
        if(!db.objectStoreNames.contains(STORE_SESSIONS)){
          const s = db.createObjectStore(STORE_SESSIONS, { keyPath: 'id', autoIncrement: true });
          s.createIndex('ts', 'ts');
        }
        if(!db.objectStoreNames.contains(STORE_GRIDS)){
          const g = db.createObjectStore(STORE_GRIDS, { keyPath: 'id' });
          g.createIndex('ts', 'ts');
        }
      };
      openReq.onerror = () => reject(openReq.error);
      openReq.onsuccess = () => action(openReq.result).then(resolve, reject);
    });
  }

  function idbGet(store, key){
    return withIDB(db => new Promise((resolve, reject)=>{
      const tx = db.transaction(store, 'readonly');
      const req = tx.objectStore(store).get(key);
      req.onsuccess = ()=> resolve(req.result);
      req.onerror = ()=> reject(req.error);
    }));
  }
  function idbPut(store, value){
    return withIDB(db => new Promise((resolve, reject)=>{
      const tx = db.transaction(store, 'readwrite');
      const req = tx.objectStore(store).put(value);
      req.onsuccess = ()=> resolve(req.result);
      req.onerror = ()=> reject(req.error);
    }));
  }
  function idbGetAll(store, index=null, direction='prev'){
    return withIDB(db => new Promise((resolve, reject)=>{
      const tx = db.transaction(store, 'readonly');
      const os = tx.objectStore(store);
      const source = index ? os.index(index) : os;
      const results = [];
      const req = source.openCursor(null, direction);
      req.onsuccess = (e)=>{
        const cursor = e.target.result;
        if(cursor){ results.push(cursor.value); cursor.continue(); }
        else resolve(results);
      };
      req.onerror = ()=> reject(req.error);
    }));
  }
  function idbDelete(store, key){
    return withIDB(db => new Promise((resolve, reject)=>{
      const tx = db.transaction(store, 'readwrite');
      const req = tx.objectStore(store).delete(key);
      req.onsuccess = ()=> resolve(true);
      req.onerror = ()=> reject(req.error);
    }));
  }

  // Fallbacks
  function lsGet(key){
    try { return Promise.resolve(JSON.parse(localStorage.getItem(key))); }
    catch{ return Promise.resolve(null); }
  }
  function lsSet(key, value){
    try { localStorage.setItem(key, JSON.stringify(value)); return Promise.resolve(true); }
    catch(e){ return Promise.reject(e); }
  }
  function lsList(prefix){
    const res = [];
    for(let i=0;i<localStorage.length;i++){
      const k = localStorage.key(i);
      if(k && k.startsWith(prefix)){
        try{ res.push(JSON.parse(localStorage.getItem(k))); }catch{}
      }
    }
    return Promise.resolve(res);
  }
  function lsDel(key){
    try { localStorage.removeItem(key); return Promise.resolve(true); } catch(e){ return Promise.reject(e); }
  }

  const api = {
    async saveSettings(settings){
      try { await idbPut(STORE_SETTINGS, { id: 'global', ...settings }); }
      catch{ await lsSet('settings:global', settings); }
      return true;
    },
    async loadSettings(){
      try {
        const v = await idbGet(STORE_SETTINGS, 'global');
        return v || (await lsGet('settings:global')) || {};
      } catch {
        return (await lsGet('settings:global')) || {};
      }
    },
    async saveSession(session){
      const doc = { ts: Date.now(), ...session };
      try { const id = await idbPut(STORE_SESSIONS, doc); return { id, ...doc }; }
      catch { // push into array fallback
        const list = (await lsGet('sessions:list')) || [];
        list.push(doc);
        await lsSet('sessions:list', list);
        return doc;
      }
    },
    async listSessions(){
      try { return await idbGetAll(STORE_SESSIONS, 'ts', 'prev'); }
      catch { const list = (await lsGet('sessions:list')) || []; return list.reverse(); }
    },
    async saveGrid(grid){
      const id = grid.id || crypto.randomUUID();
      const doc = { id, ts: Date.now(), ...grid };
      try { await idbPut(STORE_GRIDS, doc); return doc; }
      catch { await lsSet('grid:'+id, doc); return doc; }
    },
    async listGrids(){
      try { return await idbGetAll(STORE_GRIDS, 'ts', 'prev'); }
      catch { return await lsList('grid:'); }
    },
    async deleteGrid(id){
      try { await idbDelete(STORE_GRIDS, id); }
      catch { await lsDel('grid:'+id); }
      return true;
    }
  };

  global.CharsetDB = api;
})(typeof window !== 'undefined' ? window : globalThis);
