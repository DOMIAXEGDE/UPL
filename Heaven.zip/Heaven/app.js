// Standalone app adapted from the GOS module version.
// Core mapping + visualization logic, plus persistence via CharsetDB.
(async function(){
  // --- Toast helper ---
  const toastEl = document.getElementById('toast');
  function toast(msg, ms=2200){
    toastEl.textContent = msg;
    toastEl.style.display = 'block';
    clearTimeout(toastEl._t);
    toastEl._t = setTimeout(()=> toastEl.style.display='none', ms);
  }

  // --- Tabs ---
  const tabs = document.querySelectorAll('.tab-button');
  const panels = document.querySelectorAll('.content-panel');
  function switchTab(target){
    panels.forEach(p => p.classList.toggle('active', p.id === `panel-${target}`));
    tabs.forEach(t => t.classList.toggle('active', t.dataset.tab === target));
  }
  tabs.forEach(tab => tab.addEventListener('click', () => switchTab(tab.dataset.tab)));

  // --- App Config (optional) ---
  let appConfig = {
    id: 'charset-grid-viewer',
    title: 'Charset Grid Viewer',
    description: 'Standalone tool',
    version: '1.0.0'
  };
  try {
    if (location.protocol !== 'file:') {
      const res = await fetch('app-config.json');
      if (res.ok) { appConfig = await res.json(); }
    }
  } catch (e) { /* ignore: offline/file protocol */ }

  // --- Charset Map (ranges adapted from original) ---
  const CHARSET_RANGES = [
    { name: 'Basic Latin', range: [0x0020, 0x007F] }, { name: 'Latin-1 Supplement', range: [0x0080, 0x00FF] },
    { name: 'Latin Extended-A', range: [0x0100, 0x017F] }, { name: 'Latin Extended-B', range: [0x0180, 0x024F] },
    { name: 'Greek and Coptic', range: [0x0370, 0x03FF] }, { name: 'Cyrillic', range: [0x0400, 0x04FF] },
    { name: 'Arabic', range: [0x0600, 0x06FF] }, { name: 'Hebrew', range: [0x0590, 0x05FF] },
    { name: 'Devanagari', range: [0x0900, 0x097F] }, { name: 'Mathematical Operators', range: [0x2200, 0x22FF] },
    { name: 'Supplemental Mathematical Operators', range: [0x2A00, 0x2AFF] }, { name: 'Miscellaneous Technical', range: [0x2300, 0x23FF] },
    { name: 'Miscellaneous Symbols and Arrows', range: [0x2190, 0x21FF] }, { name: 'CJK Unified Ideographs', range: [0x4E00, 0x9FFF] },
    { name: 'Hangul Syllables', range: [0xAC00, 0xD7AF] }, { name: 'Hiragana', range: [0x3040, 0x309F] },
    { name: 'Katakana', range: [0x30A0, 0x30FF] }, { name: 'Bopomofo', range: [0x3100, 0x312F] },
    { name: 'Currency Symbols', range: [0x20A0, 0x20CF] }, { name: 'Additional Punctuation', range: [0x2000, 0x206F] }
  ];
  function generateCharset(){
    const set = new Set();
    CHARSET_RANGES.forEach(b => {
      for(let i=b.range[0]; i<=b.range[1]; i++){
        try { set.add(String.fromCharCode(i)); } catch {}
      }
    });
    set.add('\n'); set.add('\t');
    return Array.from(set);
  }
  const UNIQUE_CHARSET = generateCharset();

  // --- Shared helpers ---
  function downloadFile(filename, content, mimetype='text/plain'){
    const blob = new Blob([content], { type: mimetype });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
  }
  function decodeIDtoColorIndexes(idString){
    if(!idString) return [];
    return (idString.match(/.{1,7}/g) || []).map(s => parseInt(s, 10));
  }
  function updateColorBar(indexes){
    const bar = document.getElementById('color-bar');
    const isSq = (n) => n>0 && Math.sqrt(n)%1===0;
    const isValid = (idxs) => idxs.every(x => Number.isFinite(x) && x>=1 && x<=16777216);
    if(isSq(indexes.length) && isValid(indexes)){
      bar.style.backgroundColor = 'green';
      bar.title = 'Valid: the number of color indexes forms a perfect square.';
    } else {
      bar.style.backgroundColor = 'red';
      bar.title = 'Invalid: the number of color indexes does not form a perfect square.';
    }
  }
  function idToHex(id){
    id = BigInt(id);
    if(id <= 0n) return '#000000';
    return '#' + (id - 1n).toString(16).padStart(6, '0');
  }
  function calculateGridDimensions(numTiles){
    if(numTiles===0) return { rows:0, cols:0 };
    const side = Math.ceil(Math.sqrt(numTiles));
    return { rows: side, cols: side };
  }

  // --- Module: ID Generation ---
  (function(){
    const elShowGen = document.getElementById('show-generate-combinations');
    const elShowCalc = document.getElementById('show-calculate-string-id');
    const elShowDecode = document.getElementById('show-decode-id');
    const elShowOptimal = document.getElementById('show-find-optimal-variable');
    const optionContainer = document.getElementById('option-container');

    const viewIds = ['generate-combinations','calculate-string-id','decode-id','find-optimal-variable'];
    function showOption(id){
      viewIds.forEach(v => document.getElementById(v).style.display = 'none');
      document.getElementById(id).style.display = 'block';
      optionContainer.style.display = 'block';
    }

    elShowGen.addEventListener('click', ()=> showOption('generate-combinations'));
    elShowCalc.addEventListener('click', ()=> showOption('calculate-string-id'));
    elShowDecode.addEventListener('click', ()=> showOption('decode-id'));
    elShowOptimal.addEventListener('click', ()=> showOption('find-optimal-variable'));

    const mapResult = document.getElementById('map-result-display');

    // character/word count
    const customStringEl = document.getElementById('custom-string');
    const charWordEl = document.getElementById('character-word-count');
    function updateCounts(txt){
      const chars = txt.length;
      const words = txt.trim()==='' ? 0 : txt.trim().split(/\s+/).length;
      charWordEl.textContent = `Characters: ${chars}, Words: ${words}`;
    }
    customStringEl.addEventListener('input', (e)=> updateCounts(e.target.value));
    updateCounts('');

    function calculateStringID(){
      try{
        const inputString = customStringEl.value;
        if(inputString.trim() === '') throw new Error('Input string cannot be empty.');
        mapResult.innerHTML = '<p>Calculating...</p>';
        setTimeout(()=>{
          try{
            const invalid = [...new Set([...inputString].filter(ch => !UNIQUE_CHARSET.includes(ch)))];
            if(invalid.length>0) throw new Error('Invalid characters found: ' + invalid.join(''));
            let id = 0n;
            const base = BigInt(UNIQUE_CHARSET.length);
            for(const ch of inputString){
              id = id * base + BigInt(UNIQUE_CHARSET.indexOf(ch));
            }
            const resultText = id.toString();
            document.getElementById('string-id-result').innerText = 'Result ID: ' + resultText;

            const indexes = decodeIDtoColorIndexes(resultText);
            updateColorBar(indexes);

            mapResult.innerHTML = `<p>✅ Calculation complete. ID: <strong>${resultText}</strong></p>
              <button id="send-id-to-viewer">Visualize This ID</button>`;

            document.getElementById('send-id-to-viewer').addEventListener('click', ()=>{
              AlphabetApp.setInputIDAndGenerate(resultText);
              switchTab('grid-visualization');
            });

            // history context
            pushHistory({ type:'calc-id', input: inputString, id: resultText });
          }catch(err){
            mapResult.innerHTML = `<p class="error-message">${err.message}</p>`;
          }
        }, 40);
      }catch(err){
        mapResult.innerHTML = `<p class="error-message">${err.message}</p>`;
      }
    }

    function generateCombinations(){
      try{
        const n = BigInt(document.getElementById('combination-size').value);
        const outFile = document.getElementById('output-file-generate').value || 'combinations.txt';
        if(n <= 0n) throw new Error('Combination size must be a positive integer.');
        if(n > 4n && !confirm('This may generate a very large number of combinations. Continue?')) return;

        mapResult.innerHTML = '<p>Generating combinations... This may take a while.</p>';
        setTimeout(()=>{
          try{
            const k = BigInt(UNIQUE_CHARSET.length);
            const nbrComb = k ** n;
            const maxToGenerate = 100000n;
            const actualGenerate = nbrComb > maxToGenerate ? maxToGenerate : nbrComb;
            let combinations = '';
            for(let i=0n; i<actualGenerate; i++){
              let id = i; let combo = '';
              for(let j=0n; j<n; j++){
                combo = UNIQUE_CHARSET[Number(id % k)] + combo;
                id /= k;
              }
              combinations += combo + '\n';
            }
            downloadFile(outFile, combinations);
            mapResult.innerHTML = `<p class="success-message">Generated ${actualGenerate.toString()} combinations to ${outFile}.</p>`;
            pushHistory({ type:'gen-combos', n: n.toString(), file: outFile, count: actualGenerate.toString() });
          }catch(err){
            mapResult.innerHTML = `<p class="error-message">Error during generation: ${err.message}</p>`;
          }
        }, 40);
      }catch(err){
        mapResult.innerHTML = `<p class="error-message">${err.message}</p>`;
      }
    }

    function decodeID(){
      try{
        const idStr = document.getElementById('string-id').value.trim();
        if(!/^\d+$/.test(idStr)) throw new Error('ID must be a valid non-negative integer.');
        let id = BigInt(idStr);
        mapResult.innerHTML = '<p>Decoding ID...</p>';
        setTimeout(()=>{
          try{
            const base = BigInt(UNIQUE_CHARSET.length);
            let decoded = [];
            if(id === 0n && UNIQUE_CHARSET.length>0){
              decoded.push(UNIQUE_CHARSET[0]);
            } else {
              while(id > 0n){
                decoded.push(UNIQUE_CHARSET[Number(id % base)]);
                id /= base;
              }
            }
            const out = decoded.reverse().join('');
            document.getElementById('decoded-string-result').innerText = 'Decoded String: ' + out;
            mapResult.innerHTML = `<p>Decoding complete. Result: <pre>${out.replace(/[&<>]/g, s=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[s]))}</pre></p>`;
            pushHistory({ type:'decode-id', id: idStr, output: out });
          }catch(err){
            mapResult.innerHTML = `<p class="error-message">Error decoding ID: ${err.message}</p>`;
          }
        }, 40);
      }catch(err){
        mapResult.innerHTML = `<p class="error-message">${err.message}</p>`;
      }
    }

    function findOptimalVariable(){
      try{
        const userNumber = BigInt(document.getElementById('user-number').value);
        const outFile = document.getElementById('output-file-optimal').value || 'optimal_variables.txt';
        if(userNumber <= 0n) throw new Error('User number must be positive.');
        mapResult.innerHTML = '<p>Finding optimal variables...</p>';
        setTimeout(()=>{
          try{
            const base = BigInt(UNIQUE_CHARSET.length);
            function decode(num){
              if(num === 0n) return UNIQUE_CHARSET[0] || '';
              let dec = [];
              while(num > 0n){
                dec.push(UNIQUE_CHARSET[Number(num % base)]);
                num /= base;
              }
              return dec.reverse().join('');
            }
            const results = [];
            let k = 1n;
            for(let i=0; i<100; i++){
              const optVar = k * userNumber; k++;
              const str = decode(optVar);
              results.push({ variable: optVar.toString(), string: str, length: str.length });
            }
            const fileText = results.map(r => `${r.variable}\t${r.string}`).join('\n');
            downloadFile(outFile, fileText);
            let html = `<p class="success-message">Found 100 optimal variables. File '${outFile}' downloaded.</p><p>Showing first 10:</p><table class="results-table"><tr><th>Variable</th><th>String</th><th>Length</th></tr>`;
            results.slice(0,10).forEach(r => {
              html += `<tr><td>${r.variable}</td><td>${r.string}</td><td>${r.length}</td></tr>`;
            });
            html += '</table>';
            mapResult.innerHTML = html;
            pushHistory({ type:'optimal', userNumber: userNumber.toString(), file: outFile });
          }catch(err){
            mapResult.innerHTML = `<p class="error-message">Error: ${err.message}</p>`;
          }
        }, 40);
      }catch(err){
        mapResult.innerHTML = `<p class="error-message">${err.message}</p>`;
      }
    }

    document.getElementById('generate-combinations-btn').addEventListener('click', generateCombinations);
    document.getElementById('calculate-string-id-btn').addEventListener('click', calculateStringID);
    document.getElementById('decode-id-btn').addEventListener('click', decodeID);
    document.getElementById('find-optimal-variable-btn').addEventListener('click', findOptimalVariable);
  })();

  // --- Module: Grid Visualization ---
  const AlphabetApp = (function(){
    let _grids = [];
    let _currentGridIndex = 0;
    let _defaultTileSize = 64;

    const canvas = document.getElementById('grid-canvas');
    const ctx = canvas.getContext('2d');
    const tileSizeEl = document.getElementById('tile-size');
    const saveSettingsBtn = document.getElementById('save-settings');
    const prevBtn = document.getElementById('prev-grid');
    const nextBtn = document.getElementById('next-grid');
    const dlBtn = document.getElementById('download-grid-image');
    const exportGridBtn = document.getElementById('export-current-grid');
    const saveGridBtn = document.getElementById('save-grid-to-db');

    function setInputIDAndGenerate(id){
      const inputField = document.querySelector('.compounded-id-input');
      inputField.value = id;
      generateGridsFromInputs();
    }
    function regenerateGrids(compoundedIDs){
      _grids = compoundedIDs.map(id => (id.trim().match(/.{1,7}/g) || []).map(chunk => idToHex(chunk)));
      _currentGridIndex = 0;
      displayCurrentGrid();
      toast(`${_grids.length} grid(s) generated.`);
      document.getElementById('save-grid-to-db').disabled = _grids.length === 0;
    }
    function generateGridsFromInputs(){
      const ids = [...document.querySelectorAll('.compounded-id-input')].map(i => i.value.trim()).filter(Boolean);
      if(ids.length===0){ toast('Please enter at least one ID.'); return; }
      regenerateGrids(ids);
      pushHistory({ type:'grids-from-ids', ids });
    }
    async function processUploadedFile(){
      const file = document.getElementById('file-input').files[0];
      if(!file){ toast('Please select a file.'); return; }
      const text = await file.text();
      let ids = [];
      try {
        if(file.name.endsWith('.json')){
          const obj = JSON.parse(text);
          if(Array.isArray(obj.ids)) ids = obj.ids.map(String);
        }
      } catch {}
      if(ids.length===0){
        ids = text.split('\n').map(l => l.trim()).filter(l => /^\d+$/.test(l));
      }
      if(ids.length>0){
        regenerateGrids(ids);
        pushHistory({ type:'grids-from-file', file: file.name, count: ids.length });
      } else {
        toast('No valid IDs found in file.');
      }
    }
    function displayCurrentGrid(){
      const colorSequence = _grids[_currentGridIndex] || [];
      const numTiles = colorSequence.length;

      if(numTiles===0){
        canvas.width = 560; canvas.height = 120;
        ctx.clearRect(0,0,canvas.width,canvas.height);
        ctx.font = '16px ' + getComputedStyle(document.body).fontFamily;
        ctx.fillStyle = '#888'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('No grid to display.', canvas.width/2, canvas.height/2);
        updateUI(); return;
      }

      const tileSize = parseInt(tileSizeEl.value || _defaultTileSize, 10);
      const { rows, cols } = calculateGridDimensions(numTiles);
      canvas.width = cols * tileSize; canvas.height = rows * tileSize;

      ctx.clearRect(0,0,canvas.width,canvas.height);
      colorSequence.forEach((color, i) => {
        const col = i % cols, row = Math.floor(i/cols);
        ctx.fillStyle = color;
        ctx.fillRect(col*tileSize, row*tileSize, tileSize, tileSize);
        ctx.strokeStyle = '#ccc';
        ctx.strokeRect(col*tileSize, row*tileSize, tileSize, tileSize);
      });

      updateUI();
      const idxs = colorSequence.map(c => (BigInt('0x'+c.slice(1)) + 1n).toString());
      const idStr = idxs.join('').padStart(idxs.length*7,'0'); // consistent width join
      document.getElementById('current-grid-id').textContent = 'Compounded ID: ' + idStr;
      document.getElementById('color-list').innerHTML = colorSequence.map(c => {
        const id = (BigInt('0x'+c.slice(1)) + 1n).toString();
        return `<li>ID ${id}: ${c}</li>`;
      }).join('');

      updateColorBar(decodeIDtoColorIndexes(idStr));
    }
    function updateUI(){
      const colorSequence = _grids[_currentGridIndex] || [];
      document.getElementById('current-grid-position').textContent = `Grid ${_grids.length>0 ? _currentGridIndex+1 : 0} of ${_grids.length}`;
      prevBtn.disabled = _currentGridIndex === 0;
      nextBtn.disabled = _currentGridIndex >= _grids.length - 1;
      dlBtn.disabled = colorSequence.length === 0;
      exportGridBtn.disabled = colorSequence.length === 0;
      saveGridBtn.disabled = colorSequence.length === 0;
    }
    function navigateGrid(dir){
      const newIndex = _currentGridIndex + dir;
      if(newIndex>=0 && newIndex < _grids.length){
        _currentGridIndex = newIndex;
        displayCurrentGrid();
      }
    }
    function downloadGridImage(){
      const image = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = image; a.download = `grid_${_currentGridIndex+1}.png`; a.click();
    }
    function exportCurrentGrid(){
      const colorSequence = _grids[_currentGridIndex] || [];
      const payload = {
        colors: colorSequence,
        ts: Date.now(),
        meta: { index: _currentGridIndex+1, total: _grids.length, app: appConfig.id }
      };
      downloadFile('grid.json', JSON.stringify(payload, null, 2), 'application/json');
    }
    async function saveCurrentGrid(){
      const colorSequence = _grids[_currentGridIndex] || [];
      if(colorSequence.length===0) return;
      const doc = await CharsetDB.saveGrid({
        name: `Grid ${_currentGridIndex+1}`,
        colors: colorSequence
      });
      toast('Grid saved.');
      refreshSavedGrids();
    }
    async function refreshSavedGrids(){
      const list = await CharsetDB.listGrids();
      const ul = document.getElementById('saved-grids');
      ul.innerHTML = '';
      list.forEach(g => {
        const li = document.createElement('li');
        const dt = new Date(g.ts || Date.now()).toLocaleString();
        li.innerHTML = `<strong>${g.name || g.id}</strong> <small>(${dt})</small>
          <button data-id="${g.id}" class="btn-load">Load</button>
          <button data-id="${g.id}" class="btn-del">Delete</button>`;
        ul.appendChild(li);
      });
      ul.querySelectorAll('.btn-load').forEach(btn => btn.addEventListener('click', async (e)=>{
        const id = e.target.getAttribute('data-id');
        const list = await CharsetDB.listGrids();
        const g = list.find(x => x.id===id);
        if(!g){ toast('Grid not found'); return; }
        _grids = [g.colors];
        _currentGridIndex = 0;
        displayCurrentGrid();
        switchTab('grid-visualization');
      }));
      ul.querySelectorAll('.btn-del').forEach(btn => btn.addEventListener('click', async (e)=>{
        const id = e.target.getAttribute('data-id');
        await CharsetDB.deleteGrid(id);
        refreshSavedGrids();
      }));
    }

    // Settings persistence
    async function loadSettings(){
      const s = await CharsetDB.loadSettings();
      if(typeof s.tileSize === 'number'){
        tileSizeEl.value = s.tileSize;
      }
    }
    async function saveSettings(){
      const tileSize = parseInt(tileSizeEl.value, 10) || 64;
      await CharsetDB.saveSettings({ id:'global', tileSize });
      toast('Settings saved.');
    }

    // Event wiring
    tileSizeEl.addEventListener('input', displayCurrentGrid);
    saveSettingsBtn.addEventListener('click', saveSettings);
    document.getElementById('generate-grid-by-id').addEventListener('click', generateGridsFromInputs);
    document.getElementById('execute-button').addEventListener('click', processUploadedFile);
    prevBtn.addEventListener('click', ()=> navigateGrid(-1));
    nextBtn.addEventListener('click', ()=> navigateGrid(1));
    dlBtn.addEventListener('click', downloadGridImage);
    exportGridBtn.addEventListener('click', exportCurrentGrid);
    saveGridBtn.addEventListener('click', saveCurrentGrid);

    // public api
    return {
      setInputIDAndGenerate,
      refreshSavedGrids,
      loadSettings
    };
  })();
  window.AlphabetApp = AlphabetApp; // for other modules

  // --- Module: Sessions & Context ---
  const historyList = document.getElementById('history-list');
  let history = [];
  function renderHistory(){
    historyList.innerHTML = history.slice().reverse().map(h => {
      const dt = new Date(h.ts).toLocaleString();
      const payload = JSON.stringify(h.payload).slice(0,200).replace(/[&<>]/g, s=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[s]));
      return `<li><strong>${h.type}</strong> <small>${dt}</small><br/><code>${payload}</code></li>`;
    }).join('');
  }
  function pushHistory(entry){
    const doc = { ts: Date.now(), ...entry, payload: entry };
    history.push(doc);
    renderHistory();
  }
  window.pushHistory = pushHistory;

  async function saveSession(){
    const name = document.getElementById('session-name').value.trim();
    const settings = await CharsetDB.loadSettings();
    const grids = await CharsetDB.listGrids();
    const payload = { name, settings, history, savedGrids: grids, ts: Date.now(), version: (typeof appConfig.version === 'string' ? appConfig.version : '1.0.0') };
    const doc = await CharsetDB.saveSession(payload);
    toast('Session saved.');
  }
  async function loadLatestSession(){
    const sessions = await CharsetDB.listSessions();
    if(sessions.length===0){ toast('No sessions found.'); return; }
    const latest = sessions[0];
    if(latest.settings){
      await CharsetDB.saveSettings({ id:'global', ...latest.settings });
      await AlphabetApp.loadSettings();
    }
    if(Array.isArray(latest.history)){ history = latest.history; renderHistory(); }
    if(Array.isArray(latest.savedGrids)){
      // save them back (acts as sync if coming from localStorage fallback)
      for(const g of latest.savedGrids){ await CharsetDB.saveGrid(g); }
      await AlphabetApp.refreshSavedGrids();
    }
    toast('Latest session loaded.');
  }
  async function exportSession(){
    const settings = await CharsetDB.loadSettings();
    const grids = await CharsetDB.listGrids();
    const payload = { settings, history, savedGrids: grids, ts: Date.now(), app: appConfig.id, version: appConfig.version };
    downloadFile('session.json', JSON.stringify(payload, null, 2), 'application/json');
  }
  async function importSession(){
    const fileEl = document.getElementById('import-session-file');
    const f = fileEl.files[0];
    if(!f){ toast('Choose a session JSON first.'); return; }
    try {
      const obj = JSON.parse(await f.text());
      if(obj.settings){ await CharsetDB.saveSettings({ id:'global', ...obj.settings }); await AlphabetApp.loadSettings(); }
      if(Array.isArray(obj.history)){ history = obj.history; renderHistory(); }
      if(Array.isArray(obj.savedGrids)){
        for(const g of obj.savedGrids){ await CharsetDB.saveGrid(g); }
        await AlphabetApp.refreshSavedGrids();
      }
      toast('Session imported.');
    } catch (e){
      toast('Import failed: ' + e.message);
    }
  }

  document.getElementById('save-session').addEventListener('click', saveSession);
  document.getElementById('load-latest-session').addEventListener('click', loadLatestSession);
  document.getElementById('export-session').addEventListener('click', exportSession);
  document.getElementById('import-session').addEventListener('click', importSession);

  // Initial boot
  await AlphabetApp.loadSettings();
  await AlphabetApp.refreshSavedGrids();
})();
