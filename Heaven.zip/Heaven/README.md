# Charset Grid DB — Standalone

A fully offline, single‑page web app (HTML/CSS/JS) that:
- Converts strings into **unique numeric IDs** using a large custom charset.
- Decodes IDs back to strings.
- Splits IDs into 7‑digit chunks to form **color tile grids** (1..16,777,216 → #000000..#FFFFFF).
- Persists **settings, sessions, and saved grids** via IndexedDB (with localStorage fallback).
- Imports/exports **sessions** and **grids** as JSON for cross‑context portability.

## Files
- `index.html` — UI shell
- `styles.css` — theming and layout
- `app.js` — full logic (ID mapping, grids, sessions)
- `db.js` — tiny IndexedDB wrapper + localStorage fallback
- `app-config.json` — app metadata/config

## Run
Just open `index.html` in a modern browser. For strict browsers, serve with any static file server (Python: `python -m http.server`).

## Notes
- This app is adapted from your original GOS module so it works independently in any browser, with equivalent behaviour for ID mapping and grid visualization.
