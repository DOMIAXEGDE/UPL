// plugins/sequencer.js
// Minimal, non-invasive plugin: adds a "Text Sequencer" panel to Grid Visualization
// and converts block text or single-line strings into a sequence of grid IDs.
// Supports functional whitespace: space, tab (\t), newline (\n), carriage return (\r), non-breaking space (\u00A0).
// Also supports .txt/.json file input (analogous to the integer sequencing method).
(function(){
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  function init(){
    if (!window.AlphabetApp) {
      console.warn('[sequencer] AlphabetApp not found. Load app.js before this plugin.');
    }
    const gridPanel = document.getElementById('panel-grid-visualization');
    if (!gridPanel) return;

    const ui = document.createElement('section');
    ui.className = 'operation-section';
    ui.innerHTML = [
      '<div class="operation-container">',
        '<div class="operation-controls">',
          '<h2>Text Sequencer</h2>',
          '<p>Use a .txt file (or paste) to create a sequence of grids. One line = one unit (or disable splitting for whole-file-as-one).</p>',
          '<div class="row-gap">',
            '<input type="file" id="seq-file" accept=".txt,.json">',
            '<button id="seq-process-file">Process Text File</button>',
          '</div>',
          '<textarea id="seq-textarea" rows="8" placeholder="Paste text here..."></textarea>',
          '<div class="row-gap">',
            '<label><input type="checkbox" id="seq-split-lines" checked/> Split into lines</label>',
            '<label><input type="checkbox" id="seq-include-empty" /> Include empty lines</label>',
            '<label><input type="number" id="seq-autoplay-ms" min="0" value="0" title="0 = no autoplay"/> Autoplay (ms/step)</label>',
          '</div>',
          '<div class="row-gap">',
            '<button id="seq-make">Make Sequence</button>',
            '<button id="seq-play">Play</button>',
            '<button id="seq-stop" disabled>Stop</button>',
          '</div>',
          '<div class="row-gap">',
            '<small>Whitespace support: space, tab (\\t), newline (\\n), carriage return (\\r), non-breaking space (U+00A0).</small>',
          '</div>',
        '</div>',
        '<div class="operation-result">',
          '<h3>Generated IDs</h3>',
          '<ul id="seq-id-list" style="max-height:260px; overflow:auto; border:1px solid var(--accent-color); padding:0; list-style:none;"></ul>',
        '</div>',
      '</div>'
    ].join('');
    gridPanel.prepend(ui);

    // Charset identical to app.js ranges + functional whitespace
    const CHARSET_RANGES = [
      { name: 'Basic Latin', range: [0x0020, 0x007F] }, { name: 'Latin-1 Supplement', range: [0x0080, 0x00FF] },
      { name: 'Latin Extended-A', range: [0x0100, 0x017F] }, { name: 'Latin Extended-B', range: [0x0180, 0x024F] },
      { name: 'Greek and Coptic', range: [0x0370, 0x03FF] }, { name: 'Cyrillic', range: [0x0400, 0x04FF] },
      { name: 'Arabic', range: [0x0600, 0x06FF] }, { name: 'Hebrew', range: [0x0590, 0x05FF] },
      { name: 'Devanagari', range: [0x0900, 0x097F] }, { name: 'Mathematical Operators', range: [0x2200, 0x22FF] },
      { name: 'Supplemental Mathematical Operators', range: [0x2A00, 0x2AFF] }, { name: 'Miscellaneous Technical', range: [0x2300, 0x23FF] },
      { name: 'Miscellaneous Symbols and Arrows', range: [0x2190, 0x21FF] }, { name: 'CJK Unified Ideographs', range: [0x4E00, 0x9FFF] },
      { name: 'Hangul Syllables', range: [0xAC00, 0xD7AF] }, { name: 'Hiragana', range: [0x3040, 0x309F] },
      { name: 'Katakana', range: [0x30A0, 0x30FF] }, { name: 'Bopomofo', range: [0x3100, 0x312F] },
      { name: 'Currency Symbols', range: [0x20A0, 0x20CF] }, { name: 'Additional Punctuation', range: [0x2000, 0x206F] }
    ];
    function generateCharset(){
      const set = new Set();
      CHARSET_RANGES.forEach(b => {
        for(let i=b.range[0]; i<=b.range[1]; i++){
          try { set.add(String.fromCharCode(i)); } catch (e) {}
        }
      });
      set.add('\n'); set.add('\t'); set.add('\r'); set.add('\u00A0');
      return Array.from(set);
    }
    const UNIQUE_CHARSET = generateCharset();

    function strToIdString(s){
      const base = BigInt(UNIQUE_CHARSET.length);
      let id = 0n;
      const invalid = [];
      for (const ch of s){
        const idx = UNIQUE_CHARSET.indexOf(ch);
        if (idx === -1){ invalid.push(ch); continue; }
        id = id * base + BigInt(idx);
      }
      if (invalid.length){
        console.warn('[sequencer] Skipped unsupported chars:', invalid.map(c=>JSON.stringify(c)).join(''));
      }
      return id.toString();
    }

    // Elements
    const ta = ui.querySelector('#seq-textarea');
    const splitLinesEl = ui.querySelector('#seq-split-lines');
    const includeEmptyEl = ui.querySelector('#seq-include-empty');
    const autoplayMsEl = ui.querySelector('#seq-autoplay-ms');
    const makeBtn = ui.querySelector('#seq-make');
    const playBtn = ui.querySelector('#seq-play');
    const stopBtn = ui.querySelector('#seq-stop');
    const idList = ui.querySelector('#seq-id-list');
    const fileEl = ui.querySelector('#seq-file');
    const processFileBtn = ui.querySelector('#seq-process-file');

    let _ids = [];
    let _timer = null;

    // Build a sequence from an array of strings
    function buildSequenceFromUnits(units){
      if (!includeEmptyEl.checked){
        units = units.filter(line => line.length > 0);
      }
      if (units.length === 0){
        try { window.toast && window.toast('No text to convert.'); } catch (e) {}
        return;
      }
      _ids = units.map(strToIdString).filter(Boolean);
      renderIdList(_ids);
      populateAndGenerate(_ids);
    }

    // Populate existing ID inputs and generate grids
    function populateAndGenerate(ids){
      const container = document.getElementById('compounded-id-inputs');
      if (container){
        container.innerHTML = '';
        ids.forEach(id => {
          const row = document.createElement('div');
          row.className = 'compounded-id-input-row';
          row.innerHTML = '<input type="text" class="compounded-id-input" value="'+id+'">';
          container.appendChild(row);
        });
      }
      const genBtn = document.getElementById('generate-grid-by-id');
      if (genBtn){ genBtn.click(); }
      const gridTab = document.querySelector('.tab-button[data-tab="grid-visualization"]');
      if (gridTab){ gridTab.click(); }
    }

    // Render preview list
    function renderIdList(ids){
      idList.innerHTML = ids.map((id,i)=> '<li style="padding:6px 10px; border-bottom:1px solid var(--accent-color);">#'+(i+1)+': <code>'+id+'</code></li>').join('');
    }

    // Autoplay controls
    function next(){
      const nextBtn = document.getElementById('next-grid');
      if (nextBtn && !nextBtn.disabled){ nextBtn.click(); }
      else stop();
    }
    function play(){
      const ms = Math.max(0, parseInt(autoplayMsEl.value || '0', 10));
      if (!ms){
        try { window.toast && window.toast('Set autoplay ms > 0 or step manually.'); } catch (e) {}
        return;
      }
      stop();
      _timer = setInterval(next, ms);
      playBtn.disabled = true;
      stopBtn.disabled = false;
    }
    function stop(){
      if (_timer){ clearInterval(_timer); _timer = null; }
      playBtn.disabled = false;
      stopBtn.disabled = true;
    }
    playBtn.addEventListener('click', play);
    stopBtn.addEventListener('click', stop);

    // Manual (textarea) flow
    makeBtn.addEventListener('click', () => {
      const text = ta.value;
      let units = [];
      if (splitLinesEl.checked){
        units = text.split(/\r?\n/);
      } else {
        units = [text];
      }
      buildSequenceFromUnits(units);
    });

    // File-based flow (like integer sequencing method)
    processFileBtn.addEventListener('click', async () => {
      const f = fileEl.files && fileEl.files[0];
      if (!f){
        try { window.toast && window.toast('Choose a .txt or .json file first.'); } catch (e) {}
        return;
      }
      try {
        const text = await f.text();
        let units = [];

        if (f.name.toLowerCase().endswith('.json')){
          try {
            const obj = JSON.parse(text);
            if (Array.isArray(obj.strings)) {
              units = obj.strings.map(function(x){ return String(x); });
            } else if (typeof obj.text === 'string') {
              if (splitLinesEl.checked) { units = obj.text.split(/\r?\n/); }
              else { units = [obj.text]; }
            } else if (Array.isArray(obj.lines)) {
              units = obj.lines.map(function(x){ return String(x); });
            }
          } catch (e) {
            // fall back to plain text parsing if JSON parse fails
          }
        }

        if (units.length === 0){
          // Treat as plain text
          if (splitLinesEl.checked){
            units = text.split(/\r?\n/);
          } else {
            units = [text];
          }
        }
        buildSequenceFromUnits(units);
      } catch (e){
        console.error('[sequencer] Failed to read file:', e);
        try { window.toast && window.toast('Failed to read file: ' + e.message); } catch (e2) {}
      }
    });
  }
})();
