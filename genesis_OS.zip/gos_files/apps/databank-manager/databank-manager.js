export function initialize(GOS) {
    const doc = GOS.window.getContainer().ownerDocument;
    const body = doc.body;

    // 1. Inject the application's CSS styles
    const styleEl = doc.createElement('style');
    styleEl.textContent = `
		/* algorithm-themes.css */
		/* Theme Selection Variables - Default Theme */
		:root {
			/* Background Colors */
			--bg-primary: #f0f0f0;
			--bg-container: #fff;
			--bg-header: #fff;
			--bg-section-title: #f5f5f5;
			--bg-tab: #f5f5f5;
			--bg-tab-active: #fff;
			--bg-toolbar: #f9f9f9;
			--bg-register-header: #f5f5f5;
			--bg-table-header: #f9f9f9;
			--bg-multi-line: #f9f9f9;
			--bg-toast: #333;
			--bg-highlight: #fff3cd;
			--bg-editor: #fff;
			/* Text Colors */
			--text-primary: #333;
			--text-secondary: #666;
			--text-contrast: #fff;
			--text-reference: #0066cc;
			--text-resolved: #0066cc;
			/* Border Colors */
			--border-light: #ddd;
			--border-medium: #ccc;
			--border-focus: #4d90fe;
			--border-multi-line: #ddd;
			/* Button Colors */
			--btn-bg: #f0f0f0;
			--btn-hover-bg: #e0e0e0;
			--btn-border: #ccc;
			--btn-text: #333;
			/* Font Families */
			--font-primary: 'Arial', sans-serif;
			--font-mono: monospace;
			
			/* Shadows */
			--shadow-sm: 0 2px 5px rgba(0,0,0,0.1);
			--shadow-md: 0 3px 6px rgba(0,0,0,0.2);
			--shadow-lg: 0 3px 10px rgba(0,0,0,0.2);
			/* Animation */
			--transition-speed: 0.3s;
		}
		/* C++ Developer Theme */
		.theme-cpp {
			/* Background Colors */
			--bg-primary: #1e1e1e;
			--bg-container: #252526;
			--bg-header: #323233;
			--bg-section-title: #37373d;
			--bg-tab: #2d2d2d;
			--bg-tab-active: #1e1e1e;
			--bg-toolbar: #333333;
			--bg-register-header: #3c3c3c;
			--bg-table-header: #2d2d2d;
			--bg-multi-line: #1e1e1e;
			--bg-toast: #0e639c;
			--bg-highlight: #264f78;
			--bg-editor: #1e1e1e;
			/* Text Colors */
			--text-primary: #d4d4d4;
			--text-secondary: #bbbbbb;
			--text-contrast: #ffffff;
			--text-reference: #569cd6;
			--text-resolved: #4ec9b0;
			/* Border Colors */
			--border-light: #3c3c3c;
			--border-medium: #555555;
			--border-focus: #007acc;
			--border-multi-line: #3c3c3c;
			/* Button Colors */
			--btn-bg: #3c3c3c;
			--btn-hover-bg: #505050;
			--btn-border: #6a6a6a;
			--btn-text: #cccccc;
			/* Font Families */
			--font-primary: 'Consolas', 'Courier New', monospace;
			--font-mono: 'Consolas', 'Courier New', monospace;
			
			/* Shadows */
			--shadow-sm: 0 2px 5px rgba(0,0,0,0.3);
			--shadow-md: 0 3px 6px rgba(0,0,0,0.4);
			--shadow-lg: 0 3px 10px rgba(0,0,0,0.5);
		}
		/* Dark Theme */
		.theme-dark {
			/* Background Colors */
			--bg-primary: #121212;
			--bg-container: #1e1e1e;
			--bg-header: #252525;
			--bg-section-title: #2a2a2a;
			--bg-tab: #252525;
			--bg-tab-active: #333333;
			--bg-toolbar: #2a2a2a;
			--bg-register-header: #303030;
			--bg-table-header: #252525;
			--bg-multi-line: #1a1a1a;
			--bg-toast: #424242;
			--bg-highlight: #2d4f50;
			--bg-editor: #1e1e1e;
			/* Text Colors */
			--text-primary: #e0e0e0;
			--text-secondary: #b0b0b0;
			--text-contrast: #ffffff;
			--text-reference: #90caf9;
			--text-resolved: #80cbc4;
			/* Border Colors */
			--border-light: #424242;
			--border-medium: #555555;
			--border-focus: #64b5f6;
			--border-multi-line: #424242;
			/* Button Colors */
			--btn-bg: #424242;
			--btn-hover-bg: #505050;
			--btn-border: #616161;
			--btn-text: #e0e0e0;
		}
		/* Light Theme */
		.theme-light {
			/* Background Colors */
			--bg-primary: #ffffff;
			--bg-container: #ffffff;
			--bg-header: #f8f9fa;
			--bg-section-title: #f1f3f4;
			--bg-tab: #f1f3f4;
			--bg-tab-active: #ffffff;
			--bg-toolbar: #f8f9fa;
			--bg-register-header: #f1f3f4;
			--bg-table-header: #f8f9fa;
			--bg-multi-line: #f8f9fa;
			--bg-toast: #5f6368;
			--bg-highlight: #e8f0fe;
			--bg-editor: #ffffff;
			/* Text Colors */
			--text-primary: #202124;
			--text-secondary: #5f6368;
			--text-contrast: #ffffff;
			--text-reference: #1a73e8;
			--text-resolved: #188038;
			/* Border Colors */
			--border-light: #dadce0;
			--border-medium: #bdc1c6;
			--border-focus: #1a73e8;
			--border-multi-line: #dadce0;
			/* Button Colors */
			--btn-bg: #f1f3f4;
			--btn-hover-bg: #e8eaed;
			--btn-border: #dadce0;
			--btn-text: #202124;
		}
		/* Theme transition effect */
		body, body * {
			transition: background-color var(--transition-speed), 
						color var(--transition-speed), 
						border-color var(--transition-speed),
						box-shadow var(--transition-speed);
		}
		/* Global styles */
		* {
			margin: 0;
			padding: 0;
			box-sizing: border-box;
			font-family: var(--font-primary);
		}
		body {
			background-color: var(--bg-primary);
			padding: 10px;
			overflow-y: auto;
			min-height: 100vh;
			color: var(--text-primary);
		}
		.app-container {
			max-width: 100%;
			margin: 0 auto;
			background-color: var(--bg-container);
			border-radius: 5px;
			box-shadow: var(--shadow-sm);
			display: flex;
			flex-direction: column;
			min-height: calc(100vh - 20px);
			overflow: hidden;
		}
		/* Theme Selector */
		.theme-selector {
			position: absolute;
			top: 10px;
			right: 15px;
			display: flex;
			align-items: center;
			z-index: 10;
		}
		.theme-selector label {
			margin-right: 10px;
			color: var(--text-primary);
			font-size: 0.9rem;
		}
		.theme-selector select {
			padding: 5px;
			border: 1px solid var(--border-medium);
			border-radius: 3px;
			background-color: var(--bg-container);
			color: var(--text-primary);
		}
		/* Main content area - allow scrolling */
		.main-content {
			flex: 1;
			overflow-y: auto;
			-webkit-overflow-scrolling: touch; /* Smooth scrolling on iOS */
		}
		/* Header styles */
		header {
			text-align: center;
			padding: 15px;
			border-bottom: 1px solid var(--border-light);
			background-color: var(--bg-header);
		}
		header h1 {
			font-size: 1.5rem;
			font-weight: bold;
			margin-bottom: 5px;
			color: var(--text-primary);
		}
		header p {
			color: var(--text-secondary);
			font-size: 0.9rem;
		}
		/* Section styles */
		section {
			padding: 10px;
			border-bottom: 1px solid var(--border-light);
		}
		section h2 {
			font-size: 1rem;
			margin-bottom: 10px;
			padding: 5px;
			background-color: var(--bg-section-title);
			border: 1px solid var(--border-light);
			border-radius: 3px;
			color: var(--text-primary);
		}
		/* Configuration section */
		.config-grid {
			display: grid;
			grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
			gap: 10px;
			margin-bottom: 10px;
		}
		.config-item {
			display: flex;
			align-items: center;
		}
		.config-item label {
			flex: 1;
			font-size: 0.9rem;
			color: var(--text-primary);
		}
		.config-item input,
		.config-item select {
			width: 100px;
			padding: 5px;
			border: 1px solid var(--border-medium);
			border-radius: 3px;
			background-color: var(--bg-container);
			color: var(--text-primary);
		}
		.file-actions {
			display: flex;
			align-items: center;
			flex-wrap: wrap;
			gap: 10px;
			padding: 10px 0;
		}
		.file-actions label {
			margin-right: 10px;
			color: var(--text-primary);
		}
		/* Button styles */
		button {
			padding: 5px 10px;
			background-color: var(--btn-bg);
			border: 1px solid var(--btn-border);
			border-radius: 3px;
			cursor: pointer;
			font-size: 0.8rem;
			white-space: nowrap;
			color: var(--btn-text);
		}
		button:hover {
			background-color: var(--btn-hover-bg);
		}
		button:focus {
			outline: 2px solid var(--border-focus);
		}
		/* Primary button style */
		.primary-button {
			font-weight: bold;
		}
		/* Banks section */
		.banks-section {
			flex: 1;
			display: flex;
			flex-direction: column;
			overflow: hidden;
		}
		.tab-container {
			display: flex;
			border-bottom: 1px solid var(--border-light);
			overflow-x: auto;
			-webkit-overflow-scrolling: touch;
			scrollbar-width: thin;
		}
		.tab {
			padding: 8px 15px;
			background-color: var(--bg-tab);
			border: 1px solid var(--border-medium);
			border-bottom: none;
			margin-right: 1px;
			cursor: pointer;
			border-radius: 3px 3px 0 0;
			white-space: nowrap;
			color: var(--text-primary);
			position: relative;
			padding-right: 25px;
		}
		.tab:focus {
			outline: 2px solid var(--border-focus);
		}
		.tab.active {
			background-color: var(--bg-tab-active);
			border-bottom: 1px solid var(--bg-tab-active);
			margin-bottom: -1px;
		}
		.tab-title {
			font-size: 0.9rem;
		}
		.tab-close {
			position: absolute;
			right: 5px;
			top: 50%;
			transform: translateY(-50%);
			background: none;
			border: none;
			font-size: 14px;
			cursor: pointer;
			width: 16px;
			height: 16px;
			display: flex;
			align-items: center;
			justify-content: center;
			border-radius: 50%;
			opacity: 0.5;
			transition: all 0.2s;
		}
		.tab:hover .tab-close,
		.tab.active .tab-close {
			opacity: 0.8;
		}
		.tab-close:hover {
			background-color: rgba(255,0,0,0.2);
			opacity: 1;
		}
		.tab-contents {
			flex: 1;
			overflow: auto;
		}
		.tab-content {
			padding: 10px;
			display: none;
			height: 100%;
		}
		.tab-content.active {
			display: flex;
			flex-direction: column;
		}
		/* Bank display */
		.bank-toolbar {
			display: flex;
			justify-content: space-between;
			margin-bottom: 10px;
			padding: 5px;
			background-color: var(--bg-toolbar);
			border: 1px solid var(--border-light);
			border-radius: 3px;
			color: var(--text-primary);
		}
		.toolbar-title {
			display: flex;
			align-items: center;
			gap: 10px;
		}
		.toolbar-actions {
			display: flex;
			gap: 5px;
		}
		.toolbar-info {
			display: flex;
			flex-direction: column;
		}
		.toolbar-controls {
			display: flex;
			align-items: center;
			gap: 10px;
		}
		.bank-title {
			margin: 0;
		}
		.bank-stats {
			font-size: 0.8em;
			opacity: 0.7;
		}
		.edit-hint {
			font-size: 0.8em;
			opacity: 0.7;
		}
		.registers-container {
			overflow-y: auto;
			flex: 1;
		}
		.register-container {
			margin-bottom: 20px;
		}
		.register-container.collapsed .table-container {
			display: none;
		}
		.register-header {
			background-color: var(--bg-register-header);
			padding: 5px 10px;
			border: 1px solid var(--border-light);
			border-radius: 3px 3px 0 0;
			font-weight: bold;
			color: var(--text-primary);
			cursor: pointer;
			display: flex;
			justify-content: space-between;
			align-items: center;
		}
		.register-title {
			font-weight: bold;
			display: flex;
			align-items: center;
			gap: 5px;
		}
		.collapse-icon {
			font-size: 0.8em;
			font-family: monospace;
		}
		.register-count {
			font-size: 0.8em;
			opacity: 0.7;
		}
		.addresses-table {
			width: 100%;
			border-collapse: collapse;
			margin-top: 5px;
		}
		.addresses-table th,
		.addresses-table td {
			text-align: left;
			padding: 5px 10px;
			border: 1px solid var(--border-light);
			color: var(--text-primary);
		}
		.addresses-table th {
			background-color: var(--bg-table-header);
			font-weight: normal;
		}
		.sortable {
			cursor: pointer;
		}
		.sort-icon {
			font-size: 0.8em;
			margin-left: 3px;
		}
		.search-container {
			position: relative;
			display: flex;
			align-items: center;
		}
		.search-container input {
			padding-right: 25px;
		}
		.clear-search {
			position: absolute;
			right: 5px;
			background: none;
			border: none;
			font-size: 16px;
			cursor: pointer;
			padding: 0;
			width: 20px;
			height: 20px;
			display: flex;
			align-items: center;
			justify-content: center;
			opacity: 0.5;
		}
		.clear-search:hover {
			opacity: 1;
		}
		.search-match {
			animation: pulse-highlight 2s ease-in-out 1;
		}
		.highlighted {
			background-color: var(--bg-highlight, #ffffa0);
			color: var(--text-color, #000);
			border-radius: 3px;
			padding: 0 2px;
		}
		.button-container {
			display: flex;
			gap: 5px;
		}
		.copy-value {
			opacity: 0.3;
			transition: opacity 0.2s;
			font-size: 0.8em;
			padding: 2px 5px;
			margin-left: 5px;
		}
		.value-cell:hover .copy-value {
			opacity: 1;
		}
		.address-cell {
			font-weight: bold;
		}
		.reference {
			color: var(--text-reference);
			text-decoration: underline;
			cursor: pointer;
		}
		.reference:focus {
			outline: 2px solid var(--border-focus);
		}
		.highlight-pulse {
			animation: pulse-highlight 2s ease-in-out 1;
		}
		.resolved-value {
			color: var(--text-resolved);
			margin-top: 3px;
			font-style: italic;
			max-height: 200px;
			overflow-y: auto;
		}
		/* Multi-line value display */
		.multi-line-value {
			background-color: var(--bg-multi-line);
			padding: 5px;
			border-radius: 3px;
			border: 1px dashed var(--border-multi-line);
			max-height: 150px;
			overflow-y: auto;
		}
		/* Text editor */
		.editor-container {
			display: flex;
			flex-direction: column;
			flex: 1;
			min-height: 200px;
			height: calc(100vh - 250px);
			min-height: 300px;
		}
		.editor-wrapper {
			display: flex;
			flex: 1;
			border: 1px solid #ccc;
			margin-top: 5px;
			height: 100%;
		}
		.line-numbers {
			display: flex;
			flex-direction: column;
			text-align: right;
			padding: 0 5px;
			background-color: rgba(0, 0, 0, 0.05);
			color: #888;
			font-family: monospace;
			border-right: 1px solid #ddd;
			user-select: none;
			overflow: hidden;
			font-size: 14px;
			line-height: 1.5;
		}
		.text-editor {
			width: 100%;
			flex: 1;
			padding: 10px;
			border: 1px solid var(--border-light);
			font-family: var(--font-mono);
			resize: none;
			tab-size: 4;
			-moz-tab-size: 4;
			min-height: 200px;
			overflow: auto;
			white-space: pre-wrap;
			background-color: var(--bg-editor);
			color: var(--text-primary);
			font-size: 14px;
			line-height: 1.5;
			padding: 0 5px;
			border: none;
		}
		.text-editor:focus {
			outline: 2px solid var(--border-focus);
			border-color: var(--border-focus);
		}
		.syntax-hints {
			background-color: rgba(0,0,0,0.05);
			padding: 8px;
			border-radius: 4px;
			font-size: 0.9em;
			margin-bottom: 10px;
		}
		.syntax-hints code {
			background-color: rgba(0,0,0,0.1);
			padding: 2px 4px;
			border-radius: 3px;
			font-family: monospace;
		}
		/* Status bar */
		.status-bar {
			padding: 5px 10px;
			background-color: var(--bg-section-title);
			border-top: 1px solid var(--border-light);
			font-size: 0.85rem;
			color: var(--text-primary);
		}
		/* Toast notification */
		.toast {
			position: fixed;
			top: 20px;
			right: 20px;
			padding: 10px 15px;
			background-color: var(--bg-toast);
			color: var(--text-contrast);
			border-radius: 3px;
			max-width: 300px;
			z-index: 1000;
			display: none;
			box-shadow: var(--shadow-md);
		}
		.toast-fade-in {
			animation: fade-in 0.3s ease-in-out;
		}
		.progress-toast {
			position: fixed;
			bottom: 20px;
			right: 20px;
			background-color: #333;
			color: white;
			padding: 15px;
			border-radius: 4px;
			z-index: 1000;
			box-shadow: 0 2px 10px rgba(0,0,0,0.2);
			display: flex;
			flex-direction: column;
			gap: 10px;
			min-width: 250px;
		}
		.progress-bar {
			height: 10px;
			background-color: #555;
			border-radius: 5px;
			overflow: hidden;
		}
		.progress-fill {
			height: 100%;
			background-color: #4CAF50;
			transition: width 0.3s;
		}
		.progress-text {
			text-align: right;
			font-size: 0.9em;
			opacity: 0.8;
		}
		.extended {
			padding: 15px;
			max-width: 400px;
		}
		/* Modal styles */
		.modal-overlay {
			position: fixed;
			top: 0;
			left: 0;
			right: 0;
			bottom: 0;
			background-color: rgba(0,0,0,0.5);
			display: flex;
			justify-content: center;
			align-items: center;
			z-index: 100;
			display: none;
		}
		.modal {
			background-color: var(--bg-container);
			border-radius: 5px;
			padding: 20px;
			width: 90%;
			max-width: 350px;
			box-shadow: var(--shadow-lg);
		}
		.help-modal {
			max-width: 450px;
		}
		.modal-title {
			margin-bottom: 15px;
			font-size: 1.2rem;
			font-weight: bold;
			color: var(--text-primary);
		}
		.form-row {
			margin-bottom: 15px;
		}
		.form-row label {
			display: block;
			margin-bottom: 5px;
			color: var(--text-primary);
		}
		.form-row input {
			width: 100%;
			padding: 8px;
			border: 1px solid var(--border-light);
			border-radius: 3px;
			background-color: var(--bg-container);
			color: var(--text-primary);
		}
		.form-row input:focus {
			outline: 2px solid var(--border-focus);
			border-color: var(--border-focus);
		}
		.modal-buttons {
			display: flex;
			justify-content: flex-end;
			gap: 10px;
			margin-top: 20px;
		}
		.help-content {
			display: flex;
			flex-direction: column;
			gap: 10px;
			margin: 15px 0;
		}
		.shortcut-row {
			display: flex;
			justify-content: flex-start;
			align-items: center;
			gap: 15px;
		}
		.key {
			background-color: #eee;
			border: 1px solid #ddd;
			border-radius: 3px;
			padding: 2px 6px;
			font-family: monospace;
			font-size: 0.9em;
			box-shadow: 0 1px 1px rgba(0,0,0,0.2);
			min-width: 60px;
			text-align: center;
		}
		/* Preserve whitespace styles */
		.preserve-whitespace {
			white-space: pre-wrap;
			word-break: break-word;
			font-family: inherit;
		}
		.theme-cpp .reference {
			font-weight: bold;
		}
		.theme-cpp .resolved-value {
			font-family: var(--font-mono);
		}
		/* Animation keyframes */
		@keyframes pulse-highlight {
			0%, 100% { background-color: transparent; }
			50% { background-color: var(--bg-highlight, rgba(255, 255, 0, 0.3)); }
		}
		@keyframes fade-in {
			0% { opacity: 0; transform: translateY(20px); }
			100% { opacity: 1; transform: translateY(0); }
		}
		/* Responsive adjustments */
		@media (max-width: 768px) {
			.config-grid {
				grid-template-columns: 1fr;
			}
			
			.file-actions {
				flex-direction: column;
				align-items: flex-start;
			}
			
			.file-actions button {
				width: 100%;
				margin-top: 5px;
			}
			
			.bank-toolbar {
				flex-direction: column;
				align-items: flex-start;
				gap: 10px;
			}
			
			.bank-toolbar div:last-child {
				display: flex;
				gap: 5px;
			}
			
			.bank-toolbar div:last-child button {
				flex: 1;
			}
			
			.addresses-table {
				font-size: 0.9rem;
			}
			
			.tab {
				padding: 5px 10px;
				font-size: 0.9rem;
			}
			
			/* Make sure all form inputs are large enough for touch on mobile */
			button, input, select {
				min-height: 44px;
			}
			
			.theme-selector {
				position: relative;
				top: 0;
				right: 0;
				margin-bottom: 10px;
				justify-content: flex-end;
			}
			
			.toolbar-controls {
				width: 100%;
				flex-direction: column;
				align-items: stretch;
			}
			
			.search-container {
				width: 100%;
			}
			
			.search-container input {
				width: 100%;
			}
		}
		/* For small screens, adapt table layout */
		@media (max-width: 480px) {
			.addresses-table, .addresses-table tbody, .addresses-table tr {
				display: block;
				width: 100%;
			}
			
			.addresses-table th {
				display: none;
			}
			
			.addresses-table td {
				display: flex;
				padding: 8px;
				border-bottom: none;
			}
			
			.addresses-table td:first-child {
				font-weight: bold;
				background-color: var(--bg-section-title);
			}
			
			.addresses-table td:before {
				content: attr(data-label);
				font-weight: bold;
				flex: 0 0 80px;
			}
			
			.addresses-table tr {
				border: 1px solid var(--border-light);
				margin-bottom: 10px;
			}
		}
		/* Custom scrollbar for modern browsers */
		::-webkit-scrollbar {
			width: 8px;
			height: 8px;
		}
		::-webkit-scrollbar-track {
			background: var(--bg-primary);
		}
		::-webkit-scrollbar-thumb {
			background: var(--border-medium);
			border-radius: 4px;
		}
		::-webkit-scrollbar-thumb:hover {
			background: var(--border-light);
		}

	`;
    doc.head.appendChild(styleEl);

    // 2. Inject the application's HTML structure
    body.innerHTML = `
        <div class="theme-selector">
            <label for="themeSelect">Theme:</label>
            <select id="themeSelect">
                <option value="default">Default</option>
                <option value="cpp">C++ Developer</option>
                <option value="dark">Dark Mode</option>
                <option value="light">Light Mode</option>
            </select>
        </div>
        <div class="app-container">
            <header>
                <h1>DATA BANK MANAGER</h1>
                <p>Manage and query multi-level reference data files</p>
            </header>
            <div class="main-content">
                <section class="config-section">
                    <h2>BANK CONFIGURATION</h2>
                    <div class="config-grid">
                        <div class="config-item">
                            <label for="maxRegisters">Max Registers Per Bank</label>
                            <input type="number" id="maxRegisters" min="1" max="100" value="10">
                        </div>
                        <div class="config-item">
                            <label for="maxAddresses">Max Addresses Per Register</label>
                            <input type="number" id="maxAddresses" min="1" max="100" value="20">
                        </div>
                        <div class="config-item">
                            <label for="readingMode">Reading Mode</label>
                            <select id="readingMode">
                                <option value="raw">raw</option>
                                <option value="resolve">resolve</option>
                            </select>
                        </div>
                    </div>
                    <div class="file-actions">
                        <label>Bank Files</label>
                        <button id="uploadButton" tabindex="0" aria-label="Upload bank files">UPLOAD FILES</button>
                        <button id="createNewButton" tabindex="0" aria-label="Create a new bank">CREATE NEW BANK</button>
                        <button id="downloadAllButton" tabindex="0" aria-label="Download all banks as a ZIP file">DOWNLOAD ALL</button>
                        <input type="file" id="fileUpload" multiple accept=".txt" style="display: none;" aria-label="Upload bank files">
                    </div>
                </section>
                <section class="banks-section">
                    <h2>DATA BANKS</h2>
                    <div class="tab-container" id="bankTabs" role="tablist">
                        <div class="tab" id="addBankTab" role="tab" tabindex="0" aria-selected="false">+ Add</div>
                    </div>
                    <div class="tab-contents" id="bankContents">
                        </div>
                </section>
            </div>
            <div class="status-bar" id="statusBar" aria-live="polite">READY</div>
        </div>
    `;

    // 3. Adapt and execute the application's JavaScript logic

    function loadScript(url, on_load) {
        const script = doc.createElement("script");
        script.src = url;
        script.onload = on_load;
        doc.head.appendChild(script);
    }

    const app = {
        maxRegisters: 10,
        maxAddresses: 20,
        readingMode: "raw",
        banks: {},
        currentBankId: null,
        editMode: {},
        currentTheme: "default",
        undoHistory: {},
        searchTerm: "",
        filterMode: "all"
    };

    const elements = {
        maxRegisters: doc.getElementById("maxRegisters"),
        maxAddresses: doc.getElementById("maxAddresses"),
        readingMode: doc.getElementById("readingMode"),
        uploadButton: doc.getElementById("uploadButton"),
        fileUpload: doc.getElementById("fileUpload"),
        createNewButton: doc.getElementById("createNewButton"),
        downloadAllButton: doc.getElementById("downloadAllButton"),
        bankTabs: doc.getElementById("bankTabs"),
        bankContents: doc.getElementById("bankContents"),
        statusBar: doc.getElementById("statusBar"),
        addBankTab: doc.getElementById("addBankTab"),
        themeSelect: doc.getElementById("themeSelect")
    };

    function initApp() {
        elements.maxRegisters.addEventListener("change", updateConfig);
        elements.maxAddresses.addEventListener("change", updateConfig);
        elements.readingMode.addEventListener("change", updateReadingMode);
        elements.uploadButton.addEventListener("click", () => elements.fileUpload.click());
        elements.fileUpload.addEventListener("change", handleFileUpload);
        elements.createNewButton.addEventListener("click", showNewBankModal);
        elements.downloadAllButton.addEventListener("click", downloadAllBanks);
        elements.addBankTab.addEventListener("click", showNewBankModal);
        elements.themeSelect.addEventListener("change", changeTheme);
        elements.addBankTab.addEventListener("keydown", (e) => {
            if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                showNewBankModal();
            }
        });
        setupKeyboardShortcuts();
        loadConfigFromStorage();
        loadThemeFromStorage();
        showWelcomeMessage();
    }

    function showWelcomeMessage() {
        if (!localStorage.getItem("dataBankWelcomed")) {
            const welcomeHtml = `
                <div style="margin-bottom: 10px"><strong>Welcome to Data Bank Manager!</strong></div>
                <div>Get started by:</div>
                <ul>
                  <li>Uploading existing bank files using the "UPLOAD FILES" button.</li>
                  <li>Creating a new bank using the "CREATE NEW BANK" button.</li>
                </ul>
                <div style="margin-top: 10px">Press F1 for keyboard shortcuts.</div>
            `;
            GOS.ui.showDialog("Welcome!", welcomeHtml, { buttons: ['Got it!'] });
            localStorage.setItem("dataBankWelcomed", "true");
        }
    }

    function setupKeyboardShortcuts() {
        doc.addEventListener("keydown", (e) => {
            if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA" || e.target.tagName === "SELECT") {
                return;
            }
            const modifierKey = e.ctrlKey || e.metaKey;
            if (modifierKey && e.key === "s" && app.currentBankId && app.editMode[app.currentBankId]) {
                e.preventDefault();
                saveBankEdits(app.currentBankId);
            }
            if (modifierKey && e.key === "z" && app.currentBankId && app.editMode[app.currentBankId]) {
                e.preventDefault();
                undoEdit(app.currentBankId);
            }
            if (modifierKey && e.key === "n") {
                e.preventDefault();
                showNewBankModal();
            }
            if (modifierKey && e.key === "d" && app.currentBankId) {
                e.preventDefault();
                downloadBank(app.currentBankId);
            }
            if (e.key === "F1") {
                e.preventDefault();
                showHelpOverlay();
            }
        });
    }

    function showHelpOverlay() {
        const helpContent = `
            <div class="help-content" style="text-align: left;">
                <div class="shortcut-row"><span class="key">Ctrl+S</span> <span>Save current bank (in edit mode)</span></div>
                <div class="shortcut-row"><span class="key">Ctrl+Z</span> <span>Undo edit (in edit mode)</span></div>
                <div class="shortcut-row"><span class="key">Ctrl+N</span> <span>Create a new bank</span></div>
                <div class="shortcut-row"><span class="key">Ctrl+D</span> <span>Download the current bank</span></div>
                <div class="shortcut-row"><span class="key">F1</span> <span>Show this help dialog</span></div>
                <div class="shortcut-row"><span class="key">Esc</span> <span>Close dialogs</span></div>
            </div>`;
        GOS.ui.showDialog("Keyboard Shortcuts", helpContent, { buttons: ['Close'] });
    }

    function undoEdit(bankId) {
        if (app.undoHistory[bankId] && app.undoHistory[bankId].length > 0) {
            const previousState = app.undoHistory[bankId].pop();
            app.banks[bankId] = JSON.parse(previousState);
            const textEditor = doc.getElementById(`textEditor_${bankId}`);
            if (textEditor) {
                textEditor.value = generateBankText(app.banks[bankId]);
            }
            showToast("Undo successful");
        } else {
            showToast("Nothing to undo");
        }
    }

    function changeTheme() {
        const selectedTheme = elements.themeSelect.value;
        doc.body.classList.remove('theme-cpp', 'theme-dark', 'theme-light');
        if (selectedTheme !== 'default') {
            doc.body.classList.add(`theme-${selectedTheme}`);
        }
        app.currentTheme = selectedTheme;
        saveThemeToStorage();
        showToast(`Theme changed to ${selectedTheme}`);
    }

    function saveThemeToStorage() {
        try {
            localStorage.setItem("dataBankTheme", app.currentTheme);
        } catch (e) {
            console.warn("Could not save theme to local storage.", e);
        }
    }

    function loadThemeFromStorage() {
        try {
            const savedTheme = localStorage.getItem("dataBankTheme");
            if (savedTheme) {
                app.currentTheme = savedTheme;
                elements.themeSelect.value = savedTheme;
                if (savedTheme !== 'default') {
                    doc.body.classList.add(`theme-${savedTheme}`);
                }
            }
        } catch (e) {
            console.warn("Could not load theme from local storage.", e);
        }
    }

    function loadConfigFromStorage() {
        try {
            const storedConfig = localStorage.getItem("dataBankConfig");
            if (storedConfig) {
                const config = JSON.parse(storedConfig);
                app.maxRegisters = config.maxRegisters || 10;
                app.maxAddresses = config.maxAddresses || 20;
                app.readingMode = config.readingMode || "raw";
                elements.maxRegisters.value = app.maxRegisters;
                elements.maxAddresses.value = app.maxAddresses;
                elements.readingMode.value = app.readingMode;
            }
        } catch (e) {
            console.warn("Could not load config from local storage.", e);
        }
    }

    function saveConfigToStorage() {
        try {
            localStorage.setItem("dataBankConfig", JSON.stringify({
                maxRegisters: app.maxRegisters,
                maxAddresses: app.maxAddresses,
                readingMode: app.readingMode
            }));
        } catch (e) {
            console.warn("Could not save config to local storage.", e);
        }
    }

    function updateConfig() {
        app.maxRegisters = parseInt(elements.maxRegisters.value);
        app.maxAddresses = parseInt(elements.maxAddresses.value);
        saveConfigToStorage();
        showToast("Configuration updated");
    }

    function updateReadingMode() {
        app.readingMode = elements.readingMode.value;
        saveConfigToStorage();
        refreshAllBanks();
        showToast(`Reading mode changed to: ${app.readingMode}`);
    }

    function handleFileUpload(event) {
        const files = event.target.files;
        if (!files || files.length === 0) return;
        setStatusMessage(`Processing ${files.length} files...`);
        let processedCount = 0;
        let errorCount = 0;
        
        const promises = Array.from(files).map((file) => {
            return new Promise((resolve) => {
                const match = file.name.match(/^(\d+)\.txt$/);
                if (!match) {
                    showToast(`Skipped ${file.name}: Invalid filename format.`);
                    errorCount++;
                    resolve();
                    return;
                }
                const bankId = parseInt(match[1]);
                const reader = new FileReader();
                reader.onload = function(e) {
                    try {
                        processFileContent(bankId, e.target.result);
                        processedCount++;
                    } catch (err) {
                        errorCount++;
                        showToast(`Failed to process ${file.name}: ${err.message}`);
                    }
                    resolve();
                };
                reader.onerror = function() {
                    errorCount++;
                    showToast(`Error reading file: ${file.name}`);
                    resolve();
                };
                reader.readAsText(file);
            });
        });

        Promise.all(promises).then(() => {
            setStatusMessage("File processing complete.");
            if(errorCount > 0) {
                showToast(`Processed ${processedCount} files with ${errorCount} errors.`);
            } else {
                showToast(`Successfully processed ${processedCount} files.`);
            }
        });
        event.target.value = "";
    }

    function processFileContent(bankId, content) {
        const bank = parseBankData(bankId, content);
        app.banks[bankId] = bank;
        createBankTab(bankId);
        if (app.currentBankId === null) {
            selectBank(bankId);
        }
    }

    function parseBankData(bankId, content) {
        const lines = content.replace(/\r/g, '').split('\n');
        const bank = { id: bankId, registers: {} };
        let currentRegister = null;
        let inMultiLineValue = false;
        let currentAddressId = null;
        let multiLineBuffer = [];

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            if (inMultiLineValue) {
                if (line.trim() === '"""') {
                    bank.registers[currentRegister].addresses[currentAddressId] = multiLineBuffer.join('\n');
                    multiLineBuffer = [];
                    inMultiLineValue = false;
                } else {
                    multiLineBuffer.push(line);
                }
                continue;
            }

            if (!line.trim()) continue;

            if (!line.startsWith('\t')) {
                currentRegister = parseInt(line.trim());
                if (isNaN(currentRegister)) throw new Error(`Invalid register number at line ${i + 1}`);
                if (!bank.registers[currentRegister]) {
                    bank.registers[currentRegister] = { addresses: {} };
                }
            } else {
                if (currentRegister === null) throw new Error(`Address found before register at line ${i + 1}`);
                const addressLine = line.replace(/^\t+/, '');
                const parts = addressLine.split('\t', 2);
                currentAddressId = parseInt(parts[0].trim());
                if (isNaN(currentAddressId)) throw new Error(`Invalid address ID at line ${i + 1}`);
                
                if (parts.length === 1) {
                    bank.registers[currentRegister].addresses[currentAddressId] = "";
                } else if (parts[1].trim() === '"""') {
                    inMultiLineValue = true;
                    multiLineBuffer = [];
                } else {
                    bank.registers[currentRegister].addresses[currentAddressId] = parts[1];
                }
            }
        }
        if (inMultiLineValue) throw new Error('Unclosed multi-line value at end of file');
        return bank;
    }

    function createBankTab(bankId) {
        if (doc.getElementById(`bankTab_${bankId}`)) return;
        const tab = doc.createElement("div");
        tab.className = "tab";
        tab.id = `bankTab_${bankId}`;
        tab.setAttribute("role", "tab");
        tab.tabIndex = 0;
        tab.innerHTML = `<span class="tab-title">Bank ${bankId}</span><button class="tab-close" aria-label="Close Bank ${bankId}">&times;</button>`;
        
        tab.addEventListener("click", (e) => {
            if (!e.target.classList.contains("tab-close")) selectBank(bankId);
        });
        tab.addEventListener("keydown", (e) => {
            if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                selectBank(bankId);
            }
        });

        tab.querySelector(".tab-close").addEventListener("click", (e) => {
            e.stopPropagation();
            closeBank(bankId);
        });
        
        elements.bankTabs.insertBefore(tab, elements.addBankTab);
        const content = doc.createElement("div");
        content.className = "tab-content";
        content.id = `bankContent_${bankId}`;
        elements.bankContents.appendChild(content);
    }

    function closeBank(bankId) {
        GOS.ui.showDialog('Confirm Close', `Are you sure you want to close Bank ${bankId}? Any unsaved changes will be lost.`, { buttons: ['Cancel', 'Close'] })
            .then(result => {
                if (result.button === 'Close') {
                    doc.getElementById(`bankTab_${bankId}`).remove();
                    doc.getElementById(`bankContent_${bankId}`).remove();
                    delete app.banks[bankId];
                    delete app.editMode[bankId];
                    delete app.undoHistory[bankId];

                    if (app.currentBankId === bankId) {
                        app.currentBankId = null;
                        const bankIds = Object.keys(app.banks);
                        if (bankIds.length > 0) {
                            selectBank(parseInt(bankIds[0]));
                        }
                    }
                    showToast(`Bank ${bankId} closed.`);
                }
            });
    }

    function selectBank(bankId) {
        app.currentBankId = bankId;
        doc.querySelectorAll(".tab").forEach(tab => {
            tab.classList.remove("active");
            tab.setAttribute("aria-selected", "false");
        });
        const selectedTab = doc.getElementById(`bankTab_${bankId}`);
        if(selectedTab) {
            selectedTab.classList.add("active");
            selectedTab.setAttribute("aria-selected", "true");
        }
        doc.querySelectorAll(".tab-content").forEach(content => content.classList.remove("active"));
        const selectedContent = doc.getElementById(`bankContent_${bankId}`);
        if(selectedContent) {
            selectedContent.classList.add("active");
            displayBankData(bankId);
        }
    }

    function displayBankData(bankId) {
        const contentContainer = doc.getElementById(`bankContent_${bankId}`);
        if (!contentContainer) return;
        contentContainer.innerHTML = "";
        if (app.editMode[bankId]) {
            displayEditMode(bankId, contentContainer);
        } else {
            displayViewMode(bankId, contentContainer);
        }
    }

    function displayEditMode(bankId, container) {
        const toolbar = doc.createElement("div");
        toolbar.className = "bank-toolbar";
        toolbar.innerHTML = `
            <div class="toolbar-title"><span>Editing Bank ${bankId}</span><span class="edit-hint">(Ctrl+S to save)</span></div>
            <div class="toolbar-actions">
                <button id="cancelEditBank_${bankId}">Cancel</button>
                <button id="saveEditBank_${bankId}" class="primary-button">Save</button>
            </div>`;
        container.appendChild(toolbar);
        doc.getElementById(`cancelEditBank_${bankId}`).addEventListener("click", () => cancelBankEdits(bankId));
        doc.getElementById(`saveEditBank_${bankId}`).addEventListener("click", () => saveBankEdits(bankId));

        const editorContainer = doc.createElement("div");
        editorContainer.className = "editor-container";
        const textEditor = doc.createElement("textarea");
        textEditor.className = "text-editor";
        textEditor.id = `textEditor_${bankId}`;
        textEditor.value = generateBankText(app.banks[bankId]);
        editorContainer.appendChild(textEditor);
        container.appendChild(editorContainer);
        
        textEditor.addEventListener("keydown", function(e) {
            if (e.key === "Tab") {
                e.preventDefault();
                const start = this.selectionStart;
                this.value = this.value.substring(0, start) + "\t" + this.value.substring(this.selectionEnd);
                this.selectionStart = this.selectionEnd = start + 1;
            }
        });
        
        setTimeout(() => textEditor.focus(), 0);
    }
    
    function displayViewMode(bankId, container) {
        const bank = app.banks[bankId];
        container.innerHTML = `<div class="bank-toolbar"><div class="toolbar-info"><h3 class="bank-title">Bank ${bankId}</h3></div><div class="toolbar-controls"><button id="editBank_${bankId}">Edit</button><button id="downloadBank_${bankId}">Download</button></div></div><div class="registers-container"></div>`;
        doc.getElementById(`editBank_${bankId}`).addEventListener("click", () => startEditMode(bankId));
        doc.getElementById(`downloadBank_${bankId}`).addEventListener("click", () => downloadBank(bankId));
        const registersContainer = container.querySelector('.registers-container');
        const registerIds = Object.keys(bank.registers).map(id => parseInt(id)).sort((a, b) => a - b);
        registerIds.forEach(registerId => {
            const register = bank.registers[registerId];
            const registerContainer = doc.createElement("div");
            registerContainer.className = "register-container";
            registerContainer.id = `bank_${bankId}_register_${registerId}`;
            registerContainer.innerHTML = `<div class="register-header"><div class="register-title"><span class="collapse-icon">▼</span> Register ${registerId}</div></div><div class="table-container"><table class="addresses-table"><thead><tr><th>Address</th><th>Value</th></tr></thead><tbody></tbody></table></div>`;
            const tbody = registerContainer.querySelector('tbody');
            const addressIds = Object.keys(register.addresses).map(id => parseInt(id)).sort((a, b) => a - b);
            addressIds.forEach(addressId => {
                const row = doc.createElement("tr");
                row.dataset.addressId = addressId; // Add data attribute for precise selection
                const valueCell = doc.createElement("td");
                valueCell.appendChild(formatValueWithReferences(register.addresses[addressId], bankId, registerId, addressId));
                row.innerHTML = `<td>${addressId}</td>`;
                row.appendChild(valueCell);
                tbody.appendChild(row);
            });
            registerContainer.querySelector('.register-header').addEventListener("click", () => {
                registerContainer.classList.toggle("collapsed");
                registerContainer.querySelector(".collapse-icon").textContent = registerContainer.classList.contains("collapsed") ? "▶" : "▼";
            });
            registersContainer.appendChild(registerContainer);
        });
    }

    function startEditMode(bankId) {
        app.undoHistory[bankId] = [JSON.stringify(app.banks[bankId])];
        app.editMode[bankId] = true;
        displayBankData(bankId);
    }
    
    function saveBankEdits(bankId) {
        const textEditor = doc.getElementById(`textEditor_${bankId}`);
        try {
            app.banks[bankId] = parseBankData(bankId, textEditor.value);
            app.editMode[bankId] = false;
            app.undoHistory[bankId] = [];
            displayBankData(bankId);
            showToast(`Bank ${bankId} saved.`);
        } catch (e) {
            GOS.ui.showDialog("Save Error", `Could not save Bank ${bankId}:<br><pre>${e.message}</pre>`, { buttons: ['OK'] });
        }
    }

    function cancelBankEdits(bankId) {
        app.editMode[bankId] = false;
        app.banks[bankId] = JSON.parse(app.undoHistory[bankId][0]);
        app.undoHistory[bankId] = [];
        displayBankData(bankId);
    }

    function generateBankText(bank) {
        let text = "";
        const registerIds = Object.keys(bank.registers).map(Number).sort((a, b) => a - b);
        for (const registerId of registerIds) {
            text += `${registerId}\n`;
            const addressIds = Object.keys(bank.registers[registerId].addresses).map(Number).sort((a, b) => a - b);
            for (const addressId of addressIds) {
                const value = bank.registers[registerId].addresses[addressId] || "";
                if (value.includes('\n')) {
                    text += `\t${addressId}\t"""\n${value}\n\t"""\n`;
                } else {
                    text += `\t${addressId}\t${value}\n`;
                }
            }
            text += "\n";
        }
        return text;
    }

    async function showNewBankModal() {
        const bankIds = Object.keys(app.banks).map(id => parseInt(id));
        const nextId = bankIds.length > 0 ? Math.max(...bankIds) + 1 : 1;
        const dialogBody = `
            <div class="form-row"><label for="newBankId">Bank ID Number</label><input type="number" id="newBankId" min="1" value="${nextId}"></div>
            <div class="form-row"><label for="newNumRegisters">Number of Registers</label><input type="number" id="newNumRegisters" min="1" value="3"></div>
            <div class="form-row"><label for="newNumAddresses">Addresses Per Register</label><input type="number" id="newNumAddresses" min="1" value="5"></div>`;
        
        // ✅ DEFINITIVE FIX: Use `window.parent.document` to find elements in the main OS DOM.
        const getFormData = () => ({
            bankId: window.parent.document.getElementById('newBankId').value,
            numRegisters: window.parent.document.getElementById('newNumRegisters').value,
            numAddresses: window.parent.document.getElementById('newNumAddresses').value
        });

        const result = await GOS.ui.showDialog('Create New Bank', dialogBody, { buttons: ['Cancel', 'Create'], getFormData });
        
        if (result.button === 'Create' && result.formData) {
            createNewBankFromData(result.formData);
        }
    }

    function createNewBankFromData(data) {
        const bankId = parseInt(data.bankId);
        const numRegisters = parseInt(data.numRegisters);
        const numAddresses = parseInt(data.numAddresses);
        
        if (isNaN(bankId) || isNaN(numRegisters) || isNaN(numAddresses) || bankId < 1 || numRegisters < 1 || numAddresses < 1) {
            return showToast("Invalid input. Please enter positive numbers.");
        }
        if (app.banks[bankId]) {
            return showToast(`Bank ${bankId} already exists. Please choose a different ID.`);
        }

        const bank = { id: bankId, registers: {} };
        for (let r = 1; r <= numRegisters; r++) {
            bank.registers[r] = { addresses: {} };
            for (let a = 1; a <= numAddresses; a++) {
                bank.registers[r].addresses[a] = `Value ${r}.${a}`;
            }
        }
        
        app.banks[bankId] = bank;
        createBankTab(bankId);
        selectBank(bankId);
        startEditMode(bankId);
        showToast(`Bank ${bankId} created.`);
    }

	function downloadBank(bankId) {
        const bank = app.banks[bankId];
        if (!bank) return showToast(`Bank ${bankId} not found`);
        const content = generateBankText(bank);
        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
        const link = window.parent.document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `${bankId}.txt`;
        window.parent.document.body.appendChild(link);
        link.click();
        window.parent.document.body.removeChild(link);
        URL.revokeObjectURL(link.href);
    }

    function downloadAllBanks() {
        const bankIds = Object.keys(app.banks);
        if (bankIds.length === 0) return showToast("No banks to download");
        setStatusMessage("Creating ZIP file...");
        try {
            const zip = new JSZip();
            for (const bankId of bankIds) { zip.file(`${bankId}.txt`, generateBankText(app.banks[bankId])); }
            zip.generateAsync({ type: "blob" }).then(function(content) {
                const link = window.parent.document.createElement("a");
                link.href = URL.createObjectURL(content);
                link.download = "databanks.zip";
                window.parent.document.body.appendChild(link);
                link.click();
                window.parent.document.body.removeChild(link);
                URL.revokeObjectURL(link.href);
                setStatusMessage("ZIP file downloaded.");
            });
        } catch(e) { showToast("Failed to create ZIP file."); console.error(e); }
    }
	
    function highlightReferenceInCurrentBank(registerId, addressId) {
        const registerContainer = doc.getElementById(`bank_${app.currentBankId}_register_${registerId}`);
        if (registerContainer) {
            if (registerContainer.classList.contains("collapsed")) { registerContainer.querySelector('.register-header').click(); }
            const rowToHighlight = registerContainer.querySelector(`tbody tr[data-address-id="${addressId}"]`);
            if (rowToHighlight) {
                rowToHighlight.scrollIntoView({ behavior: 'smooth', block: 'center' });
                const originalColor = rowToHighlight.style.backgroundColor;
                rowToHighlight.style.transition = 'background-color 0.5s ease';
                rowToHighlight.style.backgroundColor = 'var(--bg-highlight)';
                setTimeout(() => {
                    rowToHighlight.style.backgroundColor = originalColor;
                    setTimeout(() => rowToHighlight.style.removeProperty('background-color'), 500);
                }, 2000);
                return;
            }
        }
        showToast(`Reference ${registerId}.${addressId} not found in current view.`);
    }

    function handleReferenceClick(refPath) {
        try {
            const [bankId, registerId, addressId] = refPath.split('.').map(part => parseInt(part));
            if (!app.banks[bankId]) return showToast(`Bank ${bankId} not found`);
            if (app.currentBankId !== bankId) {
                selectBank(bankId);
                setTimeout(() => highlightReferenceInCurrentBank(registerId, addressId), 200);
            } else { highlightReferenceInCurrentBank(registerId, addressId); }
        } catch (e) { showToast(`Invalid reference format: ${refPath}`); }
    }

	function resolveReference(refPath, visited = new Set()) {
        if (visited.has(refPath)) {
            return `[Circular Reference: ${refPath}]`;
        }
        visited.add(refPath);

        try {
            const [bankId, registerId, addressId] = refPath.split('.').map(part => parseInt(part));
            if (isNaN(bankId) || isNaN(registerId) || isNaN(addressId)) {
                return refPath; // Not a valid reference format
            }

            const bank = app.banks[bankId];
            if (!bank || !bank.registers[registerId] || bank.registers[registerId].addresses[addressId] === undefined) {
                return `[Unresolved: ${refPath}]`;
            }

            let value = bank.registers[registerId].addresses[addressId];
            
            // Recursively resolve nested references
            return value.replace(/(\d+\.\d+\.\d+)/g, (match) => resolveReference(match, new Set(visited)));

        } catch (e) {
            return `[Error resolving: ${refPath}]`;
        }
    }
    
	function formatValueWithReferences(value, bankId, registerId, addressId) {
        if (value === null || value === undefined) return doc.createTextNode("");
        
        const container = doc.createElement("div");
        container.style.whiteSpace = 'pre-wrap';
        if (value.includes('\n')) {
            container.classList.add("multi-line-value");
        }

        const refRegex = /(\d+\.\d+\.\d+)/g;

        // If in 'resolve' mode, resolve the entire value first
        if (app.readingMode === 'resolve') {
            let resolvedValue = value.replace(refRegex, (match) => resolveReference(match));
            
            const resolvedNode = doc.createElement('div');
            resolvedNode.className = 'resolved-value';
            resolvedNode.textContent = resolvedValue;
            
            // Show the original value with clickable references below the resolved one
            const originalNode = doc.createElement('div');
            originalNode.className = 'original-reference';
            
            const parts = value.split(refRegex);
            parts.forEach((part, i) => {
                if (i % 2 === 0) {
                    if (part) originalNode.appendChild(doc.createTextNode(part));
                } else {
                    const refLink = doc.createElement("span");
                    refLink.className = "reference";
                    refLink.textContent = part;
                    refLink.tabIndex = 0;
                    refLink.addEventListener("click", () => handleReferenceClick(part));
                    originalNode.appendChild(refLink);
                }
            });
            
            container.appendChild(resolvedNode);
            container.appendChild(originalNode);

        } else { // 'raw' mode logic (original behavior)
            const parts = value.split(refRegex);
            parts.forEach((part, i) => {
                if (i % 2 === 0) {
                    if (part) container.appendChild(doc.createTextNode(part));
                } else {
                    const refLink = doc.createElement("span");
                    refLink.className = "reference";
                    refLink.textContent = part;
                    refLink.tabIndex = 0;
                    refLink.addEventListener("click", () => handleReferenceClick(part));
                    container.appendChild(refLink);
                }
            });
        }
        
        return container;
    }
    
    function refreshAllBanks() {
        if (app.currentBankId !== null) {
            displayBankData(app.currentBankId);
        }
    }
    
    function setStatusMessage(message) {
        if (elements.statusBar) elements.statusBar.textContent = message;
    }
    
    function showToast(message) {
        GOS.ui.showNotification("Data Bank", message, 3000);
    }
    
    function escapeHtml(text) {
        const div = doc.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Load JSZip library and then initialize the app
    loadScript("https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js", () => {
        initApp();
    });
}