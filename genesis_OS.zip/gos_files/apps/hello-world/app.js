/**
 * Hello World Application for Genesis OS.
 *
 * This function is the entry point for the app. It receives a process
 * object from the kernel, which contains the windowId and other context.
 *
 * @param {object} process The process object from the kernel.
 */
function helloWorldApp(process) {
  // Find the content area of the application's window using the windowId.
  const container = document.querySelector(`#${process.windowId} .window-content`);

  // Style the container to center the text.
  container.style.display = 'flex';
  container.style.alignItems = 'center';
  container.style.justifyContent = 'center';
  container.style.fontSize = '24px';
  container.style.color = 'var(--text-color)';
  container.style.fontFamily = 'var(--font-family)';

  // Set the content.
  container.innerHTML = 'Hello, World!';
}