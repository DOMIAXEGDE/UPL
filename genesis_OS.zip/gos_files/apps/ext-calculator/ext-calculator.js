/**
 * External Calculator for Genesis OS
 * A sandboxed application that uses the 'gos' API.
 */
export function initialize(gos) {
    const container = gos.window.getContainer();
    const doc = container.ownerDocument; // The document of the iframe

    function setupDOM() {
        const css = `
            body { font-family: 'Segoe UI', 'Arial', sans-serif; }
            .calculator {
                display: flex;
                flex-direction: column;
                height: 100%;
                background-color: #252525; /* Fallback for no theme */
                background-color: var(--terminal-bg, #252525);
                color: var(--main-text, #f0f0f0);
            }
            .calculator-display {
                background-color: var(--main-bg, #1e1e1e);
                font-size: 2.5rem;
                padding: 20px;
                text-align: right;
                flex: 1;
                overflow: hidden;
                text-overflow: ellipsis;
                border-bottom: 1px solid var(--main-border, #444);
            }
            .calculator-keys {
                display: grid;
                grid-template-columns: repeat(4, 1fr);
                gap: 1px;
                background-color: var(--main-border, #444);
            }
            .calculator-keys button {
                background-color: var(--button-bg, #333);
                border: none;
                padding: 20px;
                font-size: 1.5rem;
                color: var(--main-text, #f0f0f0);
                cursor: pointer;
                transition: background-color 0.2s;
            }
            .calculator-keys button:hover {
                background-color: var(--highlight, #3f51b5);
                color: var(--main-bg, #1e1e1e);
            }
            .calculator-keys .operator {
                background-color: var(--window-header, #252525);
            }
            .calculator-keys .equals {
                grid-column: span 2;
                background-color: var(--highlight, #3f51b5);
                color: var(--main-bg, #1e1e1e);
            }
        `;

        const styleEl = doc.createElement('style');
        styleEl.textContent = css;
        doc.head.appendChild(styleEl);

        container.innerHTML = `
            <div class="calculator">
                <div id="calc-display" class="calculator-display">0</div>
                <div id="calc-keys" class="calculator-keys">
                    <button data-action="clear" class="operator">C</button>
                    <button data-action="backspace" class="operator">CE</button>
                    <button data-action="percent" class="operator">%</button>
                    <button data-action="operator" data-value="/" class="operator">÷</button>
                    <button data-action="number" data-value="7">7</button>
                    <button data-action="number" data-value="8">8</button>
                    <button data-action="number" data-value="9">9</button>
                    <button data-action="operator" data-value="*" class="operator">×</button>
                    <button data-action="number" data-value="4">4</button>
                    <button data-action="number" data-value="5">5</button>
                    <button data-action="number" data-value="6">6</button>
                    <button data-action="operator" data-value="-" class="operator">−</button>
                    <button data-action="number" data-value="1">1</button>
                    <button data-action="number" data-value="2">2</button>
                    <button data-action="number" data-value="3">3</button>
                    <button data-action="operator" data-value="+" class="operator">+</button>
                    <button data-action="number" data-value="0">0</button>
                    <button data-action="decimal" data-value=".">.</button>
                    <button data-action="equals" class="equals">=</button>
                </div>
            </div>
        `;
    }

    setupDOM();
    
    const display = container.querySelector('#calc-display');
    const keys = container.querySelector('#calc-keys');
    
    let state = {
        currentInput: '0',
        previousInput: null,
        operator: null,
        resultDisplayed: false,
    };

    const updateDisplay = () => {
        display.textContent = state.currentInput;
    };

    const calculate = () => {
        const prev = parseFloat(state.previousInput);
        const current = parseFloat(state.currentInput);
        if (isNaN(prev) || isNaN(current)) return;

        let result;
        switch (state.operator) {
            case '+': result = prev + current; break;
            case '-': result = prev - current; break;
            case '*': result = prev * current; break;
            case '/': result = prev / current; break;
            default: return;
        }
        state.currentInput = String(result);
        state.operator = null;
        state.previousInput = null;
        state.resultDisplayed = true;
    };

    keys.addEventListener('click', e => {
        if (!e.target.matches('button')) return;

        const { action, value } = e.target.dataset;

        switch (action) {
            case 'number':
                if (state.currentInput === '0' || state.resultDisplayed) {
                    state.currentInput = value;
                    state.resultDisplayed = false;
                } else {
                    state.currentInput += value;
                }
                break;
            case 'decimal':
                if (state.resultDisplayed) {
                    state.currentInput = '0.';
                    state.resultDisplayed = false;
                } else if (!state.currentInput.includes('.')) {
                    state.currentInput += '.';
                }
                break;
            case 'operator':
                if (state.operator && state.previousInput) {
                    calculate();
                }
                state.operator = value;
                state.previousInput = state.currentInput;
                state.currentInput = '0';
                break;
            case 'equals':
                if (state.operator && state.previousInput) {
                    calculate();
                }
                break;
            case 'clear':
                state.currentInput = '0';
                state.previousInput = null;
                state.operator = null;
                state.resultDisplayed = false;
                break;
            case 'backspace':
                state.currentInput = state.currentInput.slice(0, -1) || '0';
                break;
            case 'percent':
                state.currentInput = String(parseFloat(state.currentInput) / 100);
                state.resultDisplayed = true;
                break;
        }
        updateDisplay();
    });

    gos.window.setTitle("Calculator");
}