<?php
/**
 * Genesis Operating System (GOS)
 * Authentication Module
 */

/* ============================================================
 *  AUTHENTICATION MODULE
 * ============================================================ */

/**
 * Load user database from JSON file
 */
function loadUserDB() {
    global $config;
    $userDBFile = $config['filesystem']['system_dir'] . '/users.json'; // Get path from config
    if (!file_exists($userDBFile)) {
        return [];
    }
    $data = json_decode(file_get_contents($userDBFile), true);
    return is_array($data) ? $data : [];
}

/**
 * Save user database to JSON file
 */
function saveUserDB(array $users) {
    global $config;
    $userDBFile = $config['filesystem']['system_dir'] . '/users.json'; // Get path from config
    file_put_contents($userDBFile, json_encode($users, JSON_PRETTY_PRINT));
}

/**
 * Check if the user is authenticated
 */
function isAuthenticated() {
    return isset($_SESSION['user']);
}

/**
 * Get current user information
 */
function getCurrentUser() {
    return $_SESSION['user'] ?? null;
}

/**
 * Checks if the current authenticated user is an administrator.
 */
function isAdmin(): bool
{
    $user = getCurrentUser();
    // Correctly checks if 'admin' is in the user's 'roles' array.
    return $user && in_array('admin', $user['roles'] ?? [], true);
}

/**
 * Get storage quota for a user in bytes
 */
function getUserQuota(string $username) {
    foreach (loadUserDB() as $u) {
        if ($u['username'] === $username) {
            return $u['quota'] ?? (10 * 1024 * 1024);
        }
    }
    return 10 * 1024 * 1024; // default 10 MB
}

/**
 * Calculate disk usage for a user directory
 */
function getUserDiskUsage(string $username) {
    global $config;
    $dir = $config['filesystem']['user_dir'] . '/' . $username;
    if (!file_exists($dir)) {
        return 0;
    }
    $size = 0;
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)
    );
    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $size += $file->getSize();
        }
    }
    return $size;
}

/**
 * Handle authentication API requests.
 */
function handleAuthAPI() {
    jsonHeader();

    // 1. Accept JSON, FORM-POST, and plain GET
    $method = $_POST['method'] ?? $_GET['method'] ?? null;
    $params = $_POST['params'] ?? $_GET;

    // Allow legacy ?action=someAction in the query-string
    if ($method === null && isset($_GET['action'])) {
        $method = $_GET['action'];
        unset($_GET['action']);
        $params = $_GET; // The rest of the query string becomes params
    }

    // If params came in as a JSON string, decode them
    if (is_string($params)) {
        $maybeJson = json_decode($params, true);
        if ($maybeJson !== null) { $params = $maybeJson; }
    }
    
    // Fallback for direct POST data (like from the login form)
    if (empty($params) && !empty($_POST)) {
        $params = $_POST;
    }

    if ($method === null) {
        http_response_code(400);
        echo json_encode(['success' => false, 'data' => null, 'message' => 'Missing method']);
        exit;
    }

    $result = [];
    switch ($method) {
        case 'login':
            $username = $params['username'] ?? null;
            $password = $params['password'] ?? null;
            if (!$username || !$password) {
                $result = ['success' => false, 'message' => 'Missing username or password'];
                break;
            }
            
            $users = loadUserDB();
            foreach ($users as $i => $record) {
                if ($record['username'] === $username && password_verify($password, $record['password'])) {
                    $user = [
                        'username' => $record['username'],
                        'name' => $record['name'],
                        'roles' => $record['roles'] ?? ['user'],
                        'quota' => $record['quota'] ?? (10 * 1024 * 1024),
                        'lastLogin' => date('c')
                    ];
                    $_SESSION['user'] = $user;
                    session_regenerate_id(true);
                    $users[$i]['lastLogin'] = $user['lastLogin'];
                    saveUserDB($users);
                    $result = ['success' => true, 'data' => ['user' => $user, 'permissions' => getUserPermissions($user)]];
                    break 2; // Exit both loops
                }
            }
            $result = ['success' => false, 'message' => 'Invalid username or password'];
            break;

        case 'logout':
            unset($_SESSION['user']);
            $result = ['success' => true, 'message' => 'Logged out successfully'];
            break;

        case 'validateToken':
            $user = getCurrentUser();
            if ($user) {
                // CORRECTED: Pass the entire $user object
                return ['success' => true, 'data' => ['valid' => true, 'user' => $user, 'permissions' => getUserPermissions($user)]];
            }
            return ['success' => true, 'data' => ['valid' => false]];
            
        case 'getCurrentUser':
             $user = getCurrentUser();
             if ($user) {
                 $result = ['success' => true, 'data' => $user];
             } else {
                $result = ['success' => false, 'message' => 'Not authenticated'];
             }
             break;
        
        default:
            $result = ['success' => false, 'message' => 'Invalid method'];
    }

    echo json_encode($result);
    exit;
}

/**
 * Get permissions for a user based on their roles.
 */
function getUserPermissions(array $user): array
{
    // Base permissions for all authenticated users
    $permissions = [
        'app.launch.*',
        'filesystem.read.*',
        'filesystem.write.user.*',
        'filesystem.delete.user.*',
        'sandbox.execute.user'
    ];
    
    // Add permissions if the user has the 'admin' role
    if (in_array('admin', $user['roles'], true)) {
        $permissions = array_merge($permissions, [
            'filesystem.write.*',
            'filesystem.delete.*',
            'system.config.*',
            'system.admin.*',
            'sandbox.execute.*',
            'process.exec' // <-- ADD THIS MISSING PERMISSION
        ]);
    }
    
    // Add permissions if the user has the 'developer' role
    if (in_array('developer', $user['roles'], true)) {
        $permissions = array_merge($permissions, [
            'app.submit' // Example permission for developers
        ]);
    }
    
    return array_unique($permissions);
}