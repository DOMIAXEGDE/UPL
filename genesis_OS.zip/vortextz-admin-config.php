<?php
// Admin credentials - CHANGE THESE!
$ADMIN_USERNAME = 'admin';
$ADMIN_PASSWORD = '00EITA00'; // Store hashed password in production
$ADMIN_SESSION_TIMEOUT = 3600; // 1 hour
?>