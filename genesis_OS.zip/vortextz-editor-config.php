<?php
// Editor configuration
$EDITOR_TAB_SIZE = 4; // Number of spaces per tab
?>